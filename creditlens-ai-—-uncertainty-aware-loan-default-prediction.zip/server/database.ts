import fs from 'fs';
import path from 'path';
import initSqlJs, { Database } from 'sql.js';
import { LoanInput, PredictionOutput, UncertaintyLoanMLEngine } from './mlEngine.ts';

export interface StoredPredictionRecord {
  id: number;
  application_ref: string;
  applicant_name: string;
  applicant_income: number;
  loan_amount: number;
  loan_term: number;
  credit_history: number;
  employment_status: string;
  education: string;
  marital_status: string;
  property_area: string;
  existing_obligations: number;
  dti_ratio: number;
  lti_ratio: number;
  prediction: 'Likely to Repay' | 'Likely to Default';
  default_probability: number;
  confidence_score: number;
  uncertainty_score: number;
  bootstrap_std: number;
  model_disagreement: number;
  entropy_score: number;
  ci_low: number;
  ci_high: number;
  is_uncertain: boolean;
  uncertainty_reasons: string[];
  model_breakdown: Record<string, number>;
  risk_category: 'Low Risk' | 'Medium Risk' | 'High Risk';
  preprocessing_notes: string[];
  created_at: string;
}

export class LoanDatabase {
  private db!: Database;
  private readonly dbPath: string;
  private readonly schemaPath: string;

  constructor(projectRoot: string) {
    this.dbPath = path.join(projectRoot, 'Loan-Default-Prediction', 'database', 'loan_default.db');
    this.schemaPath = path.join(projectRoot, 'Loan-Default-Prediction', 'database', 'schema.sql');
  }

  public async init(mlEngine: UncertaintyLoanMLEngine): Promise<void> {
    const SQL = await initSqlJs();
    fs.mkdirSync(path.dirname(this.dbPath), { recursive: true });

    if (fs.existsSync(this.dbPath)) {
      const fileBuffer = fs.readFileSync(this.dbPath);
      this.db = new SQL.Database(fileBuffer);
    } else {
      this.db = new SQL.Database();
    }

    const schemaSql = fs.readFileSync(this.schemaPath, 'utf-8');
    this.db.run(schemaSql);
    this.persist();

    // Seed initial realistic demonstration applications only if table is empty,
    // computing EVERY prediction via the real trained ML ensemble.
    const countRes = this.db.exec('SELECT COUNT(*) as cnt FROM loan_predictions');
    const count = countRes.length > 0 ? Number(countRes[0].values[0][0]) : 0;

    if (count === 0) {
      const seedApplicants: Array<LoanInput & { ref: string; created_at: string }> = [
        {
          ref: 'APP-2026-1001',
          applicant_name: 'Arjun Mehta',
          applicant_income: 92000,
          loan_amount: 24000,
          loan_term: 48,
          credit_history: 1,
          employment_status: 'Salaried',
          education: 'Post-Graduate',
          marital_status: 'Married',
          property_area: 'Urban',
          existing_obligations: 650,
          created_at: '2026-11-18T09:15:00Z',
        },
        {
          ref: 'APP-2026-1002',
          applicant_name: 'Priya Nair',
          applicant_income: 34000,
          loan_amount: 28000,
          loan_term: 24,
          credit_history: 0,
          employment_status: 'Freelancer',
          education: 'Undergraduate',
          marital_status: 'Single',
          property_area: 'Rural',
          existing_obligations: 1100,
          created_at: '2026-11-19T11:40:00Z',
        },
        {
          ref: 'APP-2026-1003',
          applicant_name: 'Siddharth Rao',
          applicant_income: 86000,
          loan_amount: 52000,
          loan_term: 36,
          credit_history: 0,
          employment_status: 'Business Owner',
          education: 'Graduate',
          marital_status: 'Married',
          property_area: 'Urban',
          existing_obligations: 1450,
          created_at: '2026-11-20T14:22:00Z',
        },
        {
          ref: 'APP-2026-1004',
          applicant_name: 'Ananya Verma',
          applicant_income: 68500,
          loan_amount: 19500,
          loan_term: 60,
          credit_history: 1,
          employment_status: 'Salaried',
          education: 'Graduate',
          marital_status: 'Married',
          property_area: 'Semiurban',
          existing_obligations: 420,
          created_at: '2026-11-21T10:05:00Z',
        },
        {
          ref: 'APP-2026-1005',
          applicant_name: 'Kabir Sharma',
          applicant_income: 49000,
          loan_amount: 31000,
          loan_term: 36,
          credit_history: 1,
          employment_status: 'Self-Employed',
          education: 'Graduate',
          marital_status: 'Single',
          property_area: 'Semiurban',
          existing_obligations: 1580,
          created_at: '2026-11-22T16:48:00Z',
        },
        {
          ref: 'APP-2026-1006',
          applicant_name: 'Neha Kulkarni',
          applicant_income: 22500,
          loan_amount: 21000,
          loan_term: 24,
          credit_history: 0,
          employment_status: 'Unemployed',
          education: 'High School',
          marital_status: 'Divorced',
          property_area: 'Rural',
          existing_obligations: 780,
          created_at: '2026-11-23T08:30:00Z',
        },
        {
          ref: 'APP-2026-1007',
          applicant_name: 'Rohan Deshmukh',
          applicant_income: 112000,
          loan_amount: 32000,
          loan_term: 60,
          credit_history: 1,
          employment_status: 'Salaried',
          education: 'Post-Graduate',
          marital_status: 'Married',
          property_area: 'Urban',
          existing_obligations: 740,
          created_at: '2026-11-23T17:12:00Z',
        },
        {
          ref: 'APP-2026-1008',
          applicant_name: 'Meera Iyer',
          applicant_income: 58000,
          loan_amount: 34000,
          loan_term: 36,
          credit_history: 1,
          employment_status: 'Freelancer',
          education: 'Post-Graduate',
          marital_status: 'Single',
          property_area: 'Urban',
          existing_obligations: 1620,
          created_at: '2026-11-24T07:50:00Z',
        },
      ];

      for (const item of seedApplicants) {
        const result = mlEngine.predict(item);
        this.insertPrediction(item, result, item.ref, item.created_at);
      }
    }
  }

  private persist(): void {
    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  public insertPrediction(
    input: LoanInput,
    result: PredictionOutput,
    customRef?: string,
    customCreatedAt?: string
  ): StoredPredictionRecord {
    const appRef = customRef || `APP-2026-${Math.floor(1000 + Math.random() * 9000)}-${Date.now().toString().slice(-3)}`;
    const createdAt = customCreatedAt || new Date().toISOString();

    const stmt = this.db.prepare(`
      INSERT INTO loan_predictions (
        application_ref, applicant_name, applicant_income, loan_amount, loan_term,
        credit_history, employment_status, education, marital_status, property_area,
        existing_obligations, dti_ratio, lti_ratio, prediction, default_probability,
        confidence_score, uncertainty_score, bootstrap_std, model_disagreement,
        entropy_score, ci_low, ci_high, is_uncertain, uncertainty_reasons,
        model_breakdown, risk_category, preprocessing_notes, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      appRef,
      (input.applicant_name || 'Applicant').trim() || 'Applicant',
      Number(input.applicant_income ?? 0),
      Number(input.loan_amount ?? 0),
      Number(input.loan_term ?? 36),
      Number(input.credit_history ?? 1),
      input.employment_status || 'Salaried',
      input.education || 'Graduate',
      input.marital_status || 'Married',
      input.property_area || 'Urban',
      Number(input.existing_obligations ?? 0),
      result.dti_ratio,
      result.lti_ratio,
      result.prediction,
      result.default_probability,
      result.confidence_score,
      result.uncertainty_score,
      result.bootstrap_std,
      result.model_disagreement,
      result.entropy_score,
      result.ci_low,
      result.ci_high,
      result.is_uncertain ? 1 : 0,
      JSON.stringify(result.uncertainty_reasons),
      JSON.stringify(result.model_breakdown),
      result.risk_category,
      JSON.stringify(result.preprocessing_notes),
      createdAt,
    ]);
    stmt.free();
    this.persist();

    return this.getByRef(appRef)!;
  }

  private mapRow(columns: string[], values: unknown[]): StoredPredictionRecord {
    const row: Record<string, unknown> = {};
    columns.forEach((col, i) => {
      row[col] = values[i];
    });
    return {
      id: Number(row.id),
      application_ref: String(row.application_ref),
      applicant_name: String(row.applicant_name),
      applicant_income: Number(row.applicant_income),
      loan_amount: Number(row.loan_amount),
      loan_term: Number(row.loan_term),
      credit_history: Number(row.credit_history),
      employment_status: String(row.employment_status),
      education: String(row.education),
      marital_status: String(row.marital_status),
      property_area: String(row.property_area),
      existing_obligations: Number(row.existing_obligations),
      dti_ratio: Number(row.dti_ratio),
      lti_ratio: Number(row.lti_ratio),
      prediction: String(row.prediction) as StoredPredictionRecord['prediction'],
      default_probability: Number(row.default_probability),
      confidence_score: Number(row.confidence_score),
      uncertainty_score: Number(row.uncertainty_score),
      bootstrap_std: Number(row.bootstrap_std),
      model_disagreement: Number(row.model_disagreement),
      entropy_score: Number(row.entropy_score),
      ci_low: Number(row.ci_low),
      ci_high: Number(row.ci_high),
      is_uncertain: Number(row.is_uncertain) === 1,
      uncertainty_reasons: JSON.parse(String(row.uncertainty_reasons || '[]')),
      model_breakdown: JSON.parse(String(row.model_breakdown || '{}')),
      risk_category: String(row.risk_category) as StoredPredictionRecord['risk_category'],
      preprocessing_notes: JSON.parse(String(row.preprocessing_notes || '[]')),
      created_at: String(row.created_at),
    };
  }

  public getAll(): StoredPredictionRecord[] {
    const res = this.db.exec('SELECT * FROM loan_predictions ORDER BY datetime(created_at) DESC, id DESC');
    if (res.length === 0) return [];
    return res[0].values.map((vals) => this.mapRow(res[0].columns, vals));
  }

  public getById(id: number): StoredPredictionRecord | null {
    const stmt = this.db.prepare('SELECT * FROM loan_predictions WHERE id = ?');
    stmt.bind([id]);
    if (!stmt.step()) {
      stmt.free();
      return null;
    }
    const cols = stmt.getColumnNames();
    const vals = stmt.get();
    stmt.free();
    return this.mapRow(cols, vals);
  }

  public getByRef(ref: string): StoredPredictionRecord | null {
    const stmt = this.db.prepare('SELECT * FROM loan_predictions WHERE application_ref = ?');
    stmt.bind([ref]);
    if (!stmt.step()) {
      stmt.free();
      return null;
    }
    const cols = stmt.getColumnNames();
    const vals = stmt.get();
    stmt.free();
    return this.mapRow(cols, vals);
  }

  public deleteById(id: number): boolean {
    const existing = this.getById(id);
    if (!existing) return false;
    const stmt = this.db.prepare('DELETE FROM loan_predictions WHERE id = ?');
    stmt.run([id]);
    stmt.free();
    this.persist();
    return true;
  }

  public getDashboardStats() {
    const rows = this.getAll();
    const total = rows.length;
    const approved = rows.filter((r) => r.prediction === 'Likely to Repay').length;
    const defaulted = rows.filter((r) => r.prediction === 'Likely to Default').length;
    const uncertainCount = rows.filter((r) => r.is_uncertain).length;
    const lowRisk = rows.filter((r) => r.risk_category === 'Low Risk').length;
    const mediumRisk = rows.filter((r) => r.risk_category === 'Medium Risk').length;
    const highRisk = rows.filter((r) => r.risk_category === 'High Risk').length;
    const avgDefaultProb = total > 0 ? rows.reduce((s, r) => s + r.default_probability, 0) / total : 0;
    const avgUncertainty = total > 0 ? rows.reduce((s, r) => s + r.uncertainty_score, 0) / total : 0;
    const totalLoanVolume = rows.reduce((s, r) => s + r.loan_amount, 0);

    return {
      total_applications: total,
      approved_predictions: approved,
      default_predictions: defaulted,
      uncertain_predictions: uncertainCount,
      avg_default_probability: Number(avgDefaultProb.toFixed(4)),
      avg_uncertainty_score: Number(avgUncertainty.toFixed(4)),
      total_loan_volume: Number(totalLoanVolume.toFixed(2)),
      risk_distribution: {
        low: lowRisk,
        medium: mediumRisk,
        high: highRisk,
      },
    };
  }
}
