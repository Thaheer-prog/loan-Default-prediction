import fs from 'fs';
import path from 'path';

export interface LoanInput {
  applicant_name?: string;
  applicant_income: number | null;
  loan_amount: number | null;
  loan_term: number | null;
  credit_history: number | null;
  employment_status: string | null;
  education: string | null;
  marital_status: string | null;
  property_area: string | null;
  existing_obligations: number | null;
}

export interface ModelMetric {
  model: string;
  key: string;
  accuracy: number;
  precision: number;
  recall: number;
  f1_score: number;
  roc_auc: number;
  confusion_matrix: [[number, number], [number, number]];
  roc_curve: { fpr: number; tpr: number }[];
}

export interface FeatureImportanceItem {
  feature: string;
  label: string;
  importance: number;
}

export interface DatasetSummary {
  total_records: number;
  train_records: number;
  test_records: number;
  default_count: number;
  repaid_count: number;
  default_rate: number;
  missing_values_imputed: number;
  outliers_capped: number;
  feature_count: number;
}

export interface PredictionOutput {
  prediction: 'Likely to Repay' | 'Likely to Default';
  default_probability: number;
  repayment_probability: number;
  confidence_score: number;
  uncertainty_score: number;
  bootstrap_std: number;
  model_disagreement: number;
  entropy_score: number;
  ci_low: number;
  ci_high: number;
  is_uncertain: boolean;
  uncertainty_level: 'Low Uncertainty' | 'Moderate Uncertainty' | 'High Uncertainty';
  uncertainty_reasons: string[];
  risk_category: 'Low Risk' | 'Medium Risk' | 'High Risk';
  recommended_action: string;
  dti_ratio: number;
  lti_ratio: number;
  monthly_installment: number;
  preprocessing_notes: string[];
  model_breakdown: {
    logistic_regression: number;
    decision_tree: number;
    random_forest: number;
    gradient_boosting: number;
    xgboost: number;
    soft_voting_ensemble: number;
  };
  feature_contributions: { factor: string; impact: string; direction: 'risk' | 'protective' }[];
}

// Seeded PRNG for deterministic reproducible training & bootstrap sampling
function createRng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (1664525 * s + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function sigmoid(z: number): number {
  if (z >= 0) {
    const e = Math.exp(-Math.min(z, 35));
    return 1 / (1 + e);
  }
  const e = Math.exp(Math.max(z, -35));
  return e / (1 + e);
}

function logit(p: number): number {
  const c = Math.max(1e-6, Math.min(1 - 1e-6, p));
  return Math.log(c / (1 - c));
}

function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}

function mean(arr: number[]): number {
  if (arr.length === 0) return 0;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

function stdDev(arr: number[]): number {
  if (arr.length <= 1) return 0;
  const m = mean(arr);
  const variance = arr.reduce((acc, v) => acc + (v - m) ** 2, 0) / arr.length;
  return Math.sqrt(variance);
}

function quantile(sorted: number[], q: number): number {
  if (sorted.length === 0) return 0;
  const pos = (sorted.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  if (sorted[base + 1] !== undefined) {
    return sorted[base] + rest * (sorted[base + 1] - sorted[base]);
  }
  return sorted[base];
}

// Compact CART / Regression Tree Nodes
interface TreeNode {
  leaf: boolean;
  value: number; // class prob for classifier, or leaf weight for GBDT/XGB
  featureIdx?: number;
  threshold?: number;
  left?: TreeNode;
  right?: TreeNode;
}

function predictTree(node: TreeNode, x: number[]): number {
  let cur = node;
  while (!cur.leaf && cur.featureIdx !== undefined && cur.threshold !== undefined) {
    cur = x[cur.featureIdx] <= cur.threshold ? cur.left! : cur.right!;
  }
  return cur.value;
}

function fitClassificationTree(
  X: number[][],
  y: number[],
  indices: number[],
  maxDepth: number,
  minSamplesLeaf: number,
  featureSubsetSize: number | null,
  rng: () => number,
  depth = 0
): TreeNode {
  const n = indices.length;
  let posCount = 0;
  for (const idx of indices) posCount += y[idx];
  const prob = n > 0 ? posCount / n : 0.27;

  if (depth >= maxDepth || n < minSamplesLeaf * 2 || posCount === 0 || posCount === n) {
    return { leaf: true, value: prob };
  }

  const numFeatures = X[0].length;
  let candidateFeatures: number[] = [];
  for (let f = 0; f < numFeatures; f++) candidateFeatures.push(f);

  if (featureSubsetSize !== null && featureSubsetSize < numFeatures) {
    // Fisher-Yates partial shuffle
    for (let i = candidateFeatures.length - 1; i > 0; i--) {
      const j = Math.floor(rng() * (i + 1));
      [candidateFeatures[i], candidateFeatures[j]] = [candidateFeatures[j], candidateFeatures[i]];
    }
    candidateFeatures = candidateFeatures.slice(0, featureSubsetSize);
  }

  const parentGini = 1 - prob * prob - (1 - prob) * (1 - prob);
  let bestGain = 1e-6;
  let bestFeature = -1;
  let bestThresh = 0;
  let bestLeft: number[] = [];
  let bestRight: number[] = [];

  for (const f of candidateFeatures) {
    // Sample up to 16 candidate thresholds via quantiles for speed + accuracy
    const vals = indices.map((i) => X[i][f]).sort((a, b) => a - b);
    const thresholds: number[] = [];
    const steps = Math.min(14, vals.length - 1);
    for (let s = 1; s <= steps; s++) {
      const v = vals[Math.floor((s / (steps + 1)) * vals.length)];
      if (thresholds.length === 0 || Math.abs(v - thresholds[thresholds.length - 1]) > 1e-9) {
        thresholds.push(v);
      }
    }

    for (const t of thresholds) {
      let leftPos = 0;
      let leftN = 0;
      let rightPos = 0;
      let rightN = 0;
      for (const idx of indices) {
        if (X[idx][f] <= t) {
          leftN++;
          leftPos += y[idx];
        } else {
          rightN++;
          rightPos += y[idx];
        }
      }
      if (leftN < minSamplesLeaf || rightN < minSamplesLeaf) continue;

      const pL = leftPos / leftN;
      const pR = rightPos / rightN;
      const gL = 1 - pL * pL - (1 - pL) * (1 - pL);
      const gR = 1 - pR * pR - (1 - pR) * (1 - pR);
      const weightedGini = (leftN / n) * gL + (rightN / n) * gR;
      const gain = parentGini - weightedGini;

      if (gain > bestGain) {
        bestGain = gain;
        bestFeature = f;
        bestThresh = t;
      }
    }
  }

  if (bestFeature === -1) {
    return { leaf: true, value: prob };
  }

  for (const idx of indices) {
    if (X[idx][bestFeature] <= bestThresh) bestLeft.push(idx);
    else bestRight.push(idx);
  }

  return {
    leaf: false,
    value: prob,
    featureIdx: bestFeature,
    threshold: bestThresh,
    left: fitClassificationTree(X, y, bestLeft, maxDepth, minSamplesLeaf, featureSubsetSize, rng, depth + 1),
    right: fitClassificationTree(X, y, bestRight, maxDepth, minSamplesLeaf, featureSubsetSize, rng, depth + 1),
  };
}

// Second-order Gradient & Hessian Regression Tree (used for Gradient Boosting & XGBoost)
function fitNewtonTree(
  X: number[][],
  grad: number[],
  hess: number[],
  indices: number[],
  maxDepth: number,
  minChildWeight: number,
  regLambda: number,
  gamma: number,
  colSampleRatio: number,
  rng: () => number,
  depth = 0
): TreeNode {
  let sumG = 0;
  let sumH = 0;
  for (const idx of indices) {
    sumG += grad[idx];
    sumH += hess[idx];
  }
  const leafWeight = -sumG / (sumH + regLambda);

  if (depth >= maxDepth || indices.length < 10 || sumH < minChildWeight * 2) {
    return { leaf: true, value: leafWeight };
  }

  const numFeatures = X[0].length;
  let candidateFeatures: number[] = [];
  for (let f = 0; f < numFeatures; f++) candidateFeatures.push(f);
  if (colSampleRatio < 1.0) {
    const keep = Math.max(3, Math.floor(numFeatures * colSampleRatio));
    for (let i = candidateFeatures.length - 1; i > 0; i--) {
      const j = Math.floor(rng() * (i + 1));
      [candidateFeatures[i], candidateFeatures[j]] = [candidateFeatures[j], candidateFeatures[i]];
    }
    candidateFeatures = candidateFeatures.slice(0, keep);
  }

  const parentScore = (sumG * sumG) / (sumH + regLambda);
  let bestGain = gamma;
  let bestFeature = -1;
  let bestThresh = 0;

  for (const f of candidateFeatures) {
    const vals = indices.map((i) => X[i][f]).sort((a, b) => a - b);
    const thresholds: number[] = [];
    const steps = Math.min(12, vals.length - 1);
    for (let s = 1; s <= steps; s++) {
      const v = vals[Math.floor((s / (steps + 1)) * vals.length)];
      if (thresholds.length === 0 || Math.abs(v - thresholds[thresholds.length - 1]) > 1e-9) {
        thresholds.push(v);
      }
    }

    for (const t of thresholds) {
      let gL = 0, hL = 0, nL = 0;
      let gR = 0, hR = 0, nR = 0;
      for (const idx of indices) {
        if (X[idx][f] <= t) {
          gL += grad[idx];
          hL += hess[idx];
          nL++;
        } else {
          gR += grad[idx];
          hR += hess[idx];
          nR++;
        }
      }
      if (nL < 4 || nR < 4 || hL < minChildWeight || hR < minChildWeight) continue;

      const gain = 0.5 * ((gL * gL) / (hL + regLambda) + (gR * gR) / (hR + regLambda) - parentScore) - gamma;
      if (gain > bestGain) {
        bestGain = gain;
        bestFeature = f;
        bestThresh = t;
      }
    }
  }

  if (bestFeature === -1) {
    return { leaf: true, value: leafWeight };
  }

  const leftIdx: number[] = [];
  const rightIdx: number[] = [];
  for (const idx of indices) {
    if (X[idx][bestFeature] <= bestThresh) leftIdx.push(idx);
    else rightIdx.push(idx);
  }

  return {
    leaf: false,
    value: leafWeight,
    featureIdx: bestFeature,
    threshold: bestThresh,
    left: fitNewtonTree(X, grad, hess, leftIdx, maxDepth, minChildWeight, regLambda, gamma, colSampleRatio, rng, depth + 1),
    right: fitNewtonTree(X, grad, hess, rightIdx, maxDepth, minChildWeight, regLambda, gamma, colSampleRatio, rng, depth + 1),
  };
}

interface LogisticModel {
  weights: number[];
  bias: number;
}

function fitLogisticRegression(X: number[][], y: number[], epochs = 260, lr = 0.14, l2 = 0.015): LogisticModel {
  const n = X.length;
  const p = X[0].length;
  const weights = new Array(p).fill(0);
  let bias = 0;

  for (let epoch = 0; epoch < epochs; epoch++) {
    const gradW = new Array(p).fill(0);
    let gradB = 0;
    for (let i = 0; i < n; i++) {
      let z = bias;
      for (let j = 0; j < p; j++) z += weights[j] * X[i][j];
      const pred = sigmoid(z);
      const err = pred - y[i];
      gradB += err;
      for (let j = 0; j < p; j++) gradW[j] += err * X[i][j];
    }
    bias -= lr * (gradB / n);
    for (let j = 0; j < p; j++) {
      weights[j] -= lr * (gradW[j] / n + l2 * weights[j]);
    }
  }
  return { weights, bias };
}

function predictLogistic(model: LogisticModel, x: number[]): number {
  let z = model.bias;
  for (let j = 0; j < model.weights.length; j++) z += model.weights[j] * x[j];
  return sigmoid(z);
}

interface BoostedEnsemble {
  baseScore: number;
  learningRate: number;
  trees: TreeNode[];
}

function fitBoostedModel(
  X: number[][],
  y: number[],
  nEstimators: number,
  learningRate: number,
  maxDepth: number,
  regLambda: number,
  gamma: number,
  colSampleRatio: number,
  subsampleRatio: number,
  rng: () => number
): BoostedEnsemble {
  const n = X.length;
  const baseProb = clamp(mean(y), 0.05, 0.95);
  const baseScore = logit(baseProb);
  const rawPreds = new Array(n).fill(baseScore);
  const trees: TreeNode[] = [];

  for (let m = 0; m < nEstimators; m++) {
    const grad = new Array(n);
    const hess = new Array(n);
    for (let i = 0; i < n; i++) {
      const p = sigmoid(rawPreds[i]);
      grad[i] = p - y[i];
      hess[i] = Math.max(p * (1 - p), 1e-4);
    }

    const rowIdx: number[] = [];
    for (let i = 0; i < n; i++) {
      if (subsampleRatio >= 1.0 || rng() < subsampleRatio) rowIdx.push(i);
    }

    const tree = fitNewtonTree(X, grad, hess, rowIdx, maxDepth, 1.0, regLambda, gamma, colSampleRatio, rng);
    trees.push(tree);
    for (let i = 0; i < n; i++) {
      rawPreds[i] += learningRate * predictTree(tree, X[i]);
    }
  }

  return { baseScore, learningRate, trees };
}

function predictBoosted(model: BoostedEnsemble, x: number[]): number {
  let score = model.baseScore;
  for (const tree of model.trees) {
    score += model.learningRate * predictTree(tree, x);
  }
  return sigmoid(score);
}

interface PreprocessorStats {
  medians: {
    applicant_income: number;
    loan_amount: number;
    loan_term: number;
    existing_obligations: number;
  };
  modes: {
    credit_history: number;
    employment_status: string;
    education: string;
    marital_status: string;
    property_area: string;
  };
  iqrBounds: {
    applicant_income: [number, number];
    loan_amount: [number, number];
    existing_obligations: [number, number];
  };
  scalerMeans: number[];
  scalerStds: number[];
  featureNames: string[];
  featureLabels: string[];
}

const EMPLOYMENT_LEVELS = ['Salaried', 'Self-Employed', 'Business Owner', 'Freelancer', 'Unemployed'];
const EDUCATION_LEVELS = ['Graduate', 'Post-Graduate', 'Undergraduate', 'High School'];
const MARITAL_LEVELS = ['Married', 'Single', 'Divorced'];
const PROPERTY_LEVELS = ['Urban', 'Semiurban', 'Rural'];

function computeMetrics(yTrue: number[], yProb: number[], modelName: string, key: string): ModelMetric {
  let tp = 0, tn = 0, fp = 0, fn = 0;
  for (let i = 0; i < yTrue.length; i++) {
    const pred = yProb[i] >= 0.5 ? 1 : 0;
    if (yTrue[i] === 1 && pred === 1) tp++;
    else if (yTrue[i] === 0 && pred === 0) tn++;
    else if (yTrue[i] === 0 && pred === 1) fp++;
    else fn++;
  }
  const accuracy = (tp + tn) / Math.max(1, yTrue.length);
  const precision = tp / Math.max(1, tp + fp);
  const recall = tp / Math.max(1, tp + fn);
  const f1_score = (2 * precision * recall) / Math.max(1e-9, precision + recall);

  // ROC Curve across 25 thresholds
  const totalPos = Math.max(1, yTrue.filter((v) => v === 1).length);
  const totalNeg = Math.max(1, yTrue.filter((v) => v === 0).length);
  const rocPoints: { fpr: number; tpr: number }[] = [];
  for (let k = 0; k <= 25; k++) {
    const thresh = 1 - k / 25;
    let cTp = 0, cFp = 0;
    for (let i = 0; i < yTrue.length; i++) {
      if (yProb[i] >= thresh) {
        if (yTrue[i] === 1) cTp++;
        else cFp++;
      }
    }
    rocPoints.push({
      fpr: Number((cFp / totalNeg).toFixed(4)),
      tpr: Number((cTp / totalPos).toFixed(4)),
    });
  }

  // Trapezoidal ROC-AUC
  let auc = 0;
  for (let i = 1; i < rocPoints.length; i++) {
    const dx = rocPoints[i].fpr - rocPoints[i - 1].fpr;
    const avgY = (rocPoints[i].tpr + rocPoints[i - 1].tpr) / 2;
    auc += dx * avgY;
  }

  return {
    model: modelName,
    key,
    accuracy: Number(accuracy.toFixed(4)),
    precision: Number(precision.toFixed(4)),
    recall: Number(recall.toFixed(4)),
    f1_score: Number(f1_score.toFixed(4)),
    roc_auc: Number(clamp(auc, 0, 1).toFixed(4)),
    confusion_matrix: [
      [tn, fp],
      [fn, tp],
    ],
    roc_curve: rocPoints,
  };
}

export class UncertaintyLoanMLEngine {
  private preprocessor!: PreprocessorStats;
  private lrModel!: LogisticModel;
  private dtModel!: TreeNode;
  private rfModels: TreeNode[] = [];
  private gbModel!: BoostedEnsemble;
  private xgbModel!: BoostedEnsemble;
  private bootstrapModels: BoostedEnsemble[] = [];

  public metrics: ModelMetric[] = [];
  public datasetSummary!: DatasetSummary;
  public featureImportance: FeatureImportanceItem[] = [];
  public isTrained = false;

  private readonly datasetPath: string;
  private readonly evalOutPath: string;

  constructor(projectRoot: string) {
    this.datasetPath = path.join(projectRoot, 'Loan-Default-Prediction', 'dataset', 'loan_data.csv');
    this.evalOutPath = path.join(projectRoot, 'Loan-Default-Prediction', 'evaluation', 'metrics_live.json');
  }

  public train(): void {
    const rawCsv = fs.readFileSync(this.datasetPath, 'utf-8').trim();
    const lines = rawCsv.split(/\r?\n/);
    const header = lines[0].split(',');

    interface RawRow {
      applicant_income: number | null;
      loan_amount: number | null;
      loan_term: number | null;
      credit_history: number | null;
      employment_status: string | null;
      education: string | null;
      marital_status: string | null;
      property_area: string | null;
      existing_obligations: number | null;
      loan_status: number;
    }

    const rows: RawRow[] = [];
    for (let i = 1; i < lines.length; i++) {
      if (!lines[i]) continue;
      const cols = lines[i].split(',');
      const idx = (name: string) => header.indexOf(name);
      const parseNum = (v: string) => (v === '' || v === undefined ? null : Number(v));
      const parseStr = (v: string) => (v === '' || v === undefined ? null : v.trim());

      rows.push({
        applicant_income: parseNum(cols[idx('applicant_income')]),
        loan_amount: parseNum(cols[idx('loan_amount')]),
        loan_term: parseNum(cols[idx('loan_term')]),
        credit_history: parseNum(cols[idx('credit_history')]),
        employment_status: parseStr(cols[idx('employment_status')]),
        education: parseStr(cols[idx('education')]),
        marital_status: parseStr(cols[idx('marital_status')]),
        property_area: parseStr(cols[idx('property_area')]),
        existing_obligations: parseNum(cols[idx('existing_obligations')]),
        loan_status: Number(cols[idx('loan_status')]),
      });
    }

    // Stratified 80/20 split using deterministic shuffle
    const rng = createRng(42);
    const posIndices: number[] = [];
    const negIndices: number[] = [];
    rows.forEach((r, idx) => (r.loan_status === 1 ? posIndices.push(idx) : negIndices.push(idx)));

    const shuffle = (arr: number[]) => {
      for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(rng() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
      }
    };
    shuffle(posIndices);
    shuffle(negIndices);

    const posSplit = Math.floor(posIndices.length * 0.8);
    const negSplit = Math.floor(negIndices.length * 0.8);

    const trainIdx = [...posIndices.slice(0, posSplit), ...negIndices.slice(0, negSplit)];
    const testIdx = [...posIndices.slice(posSplit), ...negIndices.slice(negSplit)];
    shuffle(trainIdx);
    shuffle(testIdx);

    const trainRows = trainIdx.map((i) => rows[i]);
    const testRows = testIdx.map((i) => rows[i]);

    // Compute Imputation Stats on Training Set Only
    const getNums = (fn: (r: RawRow) => number | null) =>
      trainRows.map(fn).filter((v): v is number => v !== null && !Number.isNaN(v)).sort((a, b) => a - b);

    const modeStr = (fn: (r: RawRow) => string | null, fallback: string) => {
      const counts = new Map<string, number>();
      for (const r of trainRows) {
        const v = fn(r);
        if (v) counts.set(v, (counts.get(v) || 0) + 1);
      }
      let best = fallback;
      let maxC = -1;
      for (const [k, c] of counts.entries()) {
        if (c > maxC) {
          maxC = c;
          best = k;
        }
      }
      return best;
    };

    const incNums = getNums((r) => r.applicant_income);
    const loanNums = getNums((r) => r.loan_amount);
    const termNums = getNums((r) => r.loan_term);
    const oblNums = getNums((r) => r.existing_obligations);
    const chNums = getNums((r) => r.credit_history);

    const iqrFence = (sorted: number[]): [number, number] => {
      const q1 = quantile(sorted, 0.25);
      const q3 = quantile(sorted, 0.75);
      const iqr = q3 - q1;
      return [Math.max(0, q1 - 1.5 * iqr), q3 + 2.2 * iqr];
    };

    const chOnes = chNums.filter((v) => v === 1).length;

    const featureNames = [
      'applicant_income',
      'loan_amount',
      'loan_term',
      'credit_history',
      'existing_obligations',
      'dti_ratio',
      'lti_ratio',
      'monthly_installment',
      ...EMPLOYMENT_LEVELS.map((e) => `emp_${e}`),
      ...EDUCATION_LEVELS.map((e) => `edu_${e}`),
      ...MARITAL_LEVELS.map((m) => `mar_${m}`),
      ...PROPERTY_LEVELS.map((p) => `prop_${p}`),
    ];

    const featureLabels = [
      'Applicant Income',
      'Loan Amount',
      'Loan Term (Months)',
      'Credit History (Clean=1)',
      'Existing Obligations',
      'Debt-to-Income Ratio',
      'Loan-to-Income Ratio',
      'Monthly Installment',
      ...EMPLOYMENT_LEVELS.map((e) => `Employment: ${e}`),
      ...EDUCATION_LEVELS.map((e) => `Education: ${e}`),
      ...MARITAL_LEVELS.map((m) => `Marital: ${m}`),
      ...PROPERTY_LEVELS.map((p) => `Property: ${p}`),
    ];

    this.preprocessor = {
      medians: {
        applicant_income: quantile(incNums, 0.5),
        loan_amount: quantile(loanNums, 0.5),
        loan_term: quantile(termNums, 0.5),
        existing_obligations: quantile(oblNums, 0.5),
      },
      modes: {
        credit_history: chOnes >= chNums.length / 2 ? 1 : 0,
        employment_status: modeStr((r) => r.employment_status, 'Salaried'),
        education: modeStr((r) => r.education, 'Graduate'),
        marital_status: modeStr((r) => r.marital_status, 'Married'),
        property_area: modeStr((r) => r.property_area, 'Urban'),
      },
      iqrBounds: {
        applicant_income: iqrFence(incNums),
        loan_amount: iqrFence(loanNums),
        existing_obligations: iqrFence(oblNums),
      },
      scalerMeans: new Array(featureNames.length).fill(0),
      scalerStds: new Array(featureNames.length).fill(1),
      featureNames,
      featureLabels,
    };

    let missingCount = 0;
    let outlierCount = 0;

    const buildRawVector = (r: LoanInput, trackStats = false) => {
      const notes: string[] = [];
      let inc = r.applicant_income;
      if (inc === null || Number.isNaN(inc)) {
        inc = this.preprocessor.medians.applicant_income;
        if (trackStats) missingCount++;
        notes.push('Imputed missing applicant income with training median');
      }
      if (inc < this.preprocessor.iqrBounds.applicant_income[0] || inc > this.preprocessor.iqrBounds.applicant_income[1]) {
        if (trackStats) outlierCount++;
        notes.push('Applicant income capped via IQR outlier fence');
        inc = clamp(inc, this.preprocessor.iqrBounds.applicant_income[0], this.preprocessor.iqrBounds.applicant_income[1]);
      }

      let loan = r.loan_amount;
      if (loan === null || Number.isNaN(loan)) {
        loan = this.preprocessor.medians.loan_amount;
        if (trackStats) missingCount++;
        notes.push('Imputed missing loan amount with training median');
      }
      if (loan < this.preprocessor.iqrBounds.loan_amount[0] || loan > this.preprocessor.iqrBounds.loan_amount[1]) {
        if (trackStats) outlierCount++;
        notes.push('Loan amount capped via IQR outlier fence');
        loan = clamp(loan, this.preprocessor.iqrBounds.loan_amount[0], this.preprocessor.iqrBounds.loan_amount[1]);
      }

      let term = r.loan_term;
      if (term === null || Number.isNaN(term) || term <= 0) {
        term = this.preprocessor.medians.loan_term;
        if (trackStats) missingCount++;
        notes.push('Imputed missing loan term with training median');
      }

      let ch = r.credit_history;
      if (ch === null || Number.isNaN(ch)) {
        ch = this.preprocessor.modes.credit_history;
        if (trackStats) missingCount++;
        notes.push('Imputed missing credit history with training mode');
      }

      let obl = r.existing_obligations;
      if (obl === null || Number.isNaN(obl)) {
        obl = this.preprocessor.medians.existing_obligations;
        if (trackStats) missingCount++;
        notes.push('Imputed missing obligations with training median');
      }
      if (obl > this.preprocessor.iqrBounds.existing_obligations[1]) {
        if (trackStats) outlierCount++;
        notes.push('Existing obligations capped via IQR outlier fence');
        obl = clamp(obl, 0, this.preprocessor.iqrBounds.existing_obligations[1]);
      }

      let emp = r.employment_status;
      if (!emp || !EMPLOYMENT_LEVELS.includes(emp)) {
        emp = this.preprocessor.modes.employment_status;
        if (trackStats) missingCount++;
      }
      const edu = r.education && EDUCATION_LEVELS.includes(r.education) ? r.education : this.preprocessor.modes.education;
      const mar = r.marital_status && MARITAL_LEVELS.includes(r.marital_status) ? r.marital_status : this.preprocessor.modes.marital_status;
      const prop = r.property_area && PROPERTY_LEVELS.includes(r.property_area) ? r.property_area : this.preprocessor.modes.property_area;

      const monthlyIncome = Math.max(inc / 12, 1);
      const monthlyInstallment = loan / Math.max(term, 1);
      const dti = (obl + monthlyInstallment) / monthlyIncome;
      const lti = loan / Math.max(inc, 1);

      const vec = [
        inc,
        loan,
        term,
        ch,
        obl,
        dti,
        lti,
        monthlyInstallment,
        ...EMPLOYMENT_LEVELS.map((e) => (emp === e ? 1 : 0)),
        ...EDUCATION_LEVELS.map((e) => (edu === e ? 1 : 0)),
        ...MARITAL_LEVELS.map((m) => (mar === m ? 1 : 0)),
        ...PROPERTY_LEVELS.map((p) => (prop === p ? 1 : 0)),
      ];
      return { vec, dti, lti, monthlyInstallment, notes };
    };

    const rawTrainVectors = trainRows.map((r) => buildRawVector(r, true).vec);
    const rawTestVectors = testRows.map((r) => buildRawVector(r, true).vec);

    // Fit StandardScaler on numeric/engineered indices (0..7)
    for (let j = 0; j < 8; j++) {
      const col = rawTrainVectors.map((v) => v[j]);
      this.preprocessor.scalerMeans[j] = mean(col);
      this.preprocessor.scalerStds[j] = Math.max(stdDev(col), 1e-6);
    }

    const scaleVec = (vec: number[]) =>
      vec.map((v, j) => (j < 8 ? (v - this.preprocessor.scalerMeans[j]) / this.preprocessor.scalerStds[j] : v));

    const XTrain = rawTrainVectors.map(scaleVec);
    const yTrain = trainRows.map((r) => r.loan_status);
    const XTest = rawTestVectors.map(scaleVec);
    const yTest = testRows.map((r) => r.loan_status);

    const allTrainIdx = Array.from({ length: XTrain.length }, (_, i) => i);

    // 1. Logistic Regression
    this.lrModel = fitLogisticRegression(XTrain, yTrain, 280, 0.16, 0.01);

    // 2. Decision Tree
    this.dtModel = fitClassificationTree(XTrain, yTrain, allTrainIdx, 5, 8, null, rng);

    // 3. Random Forest (25 bagged trees)
    this.rfModels = [];
    const rfSubFeatures = Math.max(5, Math.floor(Math.sqrt(XTrain[0].length)) + 1);
    for (let t = 0; t < 25; t++) {
      const bootIdx = Array.from({ length: XTrain.length }, () => Math.floor(rng() * XTrain.length));
      this.rfModels.push(fitClassificationTree(XTrain, yTrain, bootIdx, 7, 4, rfSubFeatures, rng));
    }

    // 4. Gradient Boosting (30 trees)
    this.gbModel = fitBoostedModel(XTrain, yTrain, 30, 0.12, 3, 0.4, 0.0, 1.0, 0.85, rng);

    // 5. XGBoost (38 regularized Newton-Raphson boosted trees with colsubsampling + gamma)
    this.xgbModel = fitBoostedModel(XTrain, yTrain, 38, 0.11, 3, 1.2, 0.05, 0.85, 0.85, rng);

    // 6. Bootstrap Ensemble for Epistemic Uncertainty (14 resampled regularized boosted models)
    this.bootstrapModels = [];
    for (let b = 0; b < 14; b++) {
      const bootX: number[][] = [];
      const bootY: number[] = [];
      for (let i = 0; i < XTrain.length; i++) {
        const pick = Math.floor(rng() * XTrain.length);
        bootX.push(XTrain[pick]);
        bootY.push(yTrain[pick]);
      }
      this.bootstrapModels.push(fitBoostedModel(bootX, bootY, 16, 0.16, 3, 1.2, 0.04, 0.85, 1.0, rng));
    }

    // Evaluate all 6 models on Test Set
    const lrProbs = XTest.map((x) => predictLogistic(this.lrModel, x));
    const dtProbs = XTest.map((x) => predictTree(this.dtModel, x));
    const rfProbs = XTest.map((x) => mean(this.rfModels.map((t) => predictTree(t, x))));
    const gbProbs = XTest.map((x) => predictBoosted(this.gbModel, x));
    const xgbProbs = XTest.map((x) => predictBoosted(this.xgbModel, x));
    const ensProbs = XTest.map((_, i) =>
      0.14 * lrProbs[i] + 0.04 * dtProbs[i] + 0.22 * rfProbs[i] + 0.28 * gbProbs[i] + 0.32 * xgbProbs[i]
    );

    this.metrics = [
      computeMetrics(yTest, lrProbs, 'Logistic Regression', 'logistic_regression'),
      computeMetrics(yTest, dtProbs, 'Decision Tree', 'decision_tree'),
      computeMetrics(yTest, rfProbs, 'Random Forest', 'random_forest'),
      computeMetrics(yTest, gbProbs, 'Gradient Boosting', 'gradient_boosting'),
      computeMetrics(yTest, xgbProbs, 'XGBoost', 'xgboost'),
      computeMetrics(yTest, ensProbs, 'Soft Voting Ensemble', 'soft_voting_ensemble'),
    ];

    // Compute Feature Importance via permutation importance on Test Set for Soft Voting Ensemble
    const baseAuc = this.metrics[5].roc_auc;
    const rawImportances: { feature: string; label: string; score: number }[] = [];
    for (let f = 0; f < 14; f++) {
      const permX = XTest.map((row) => [...row]);
      const colVals = permX.map((r) => r[f]);
      for (let i = colVals.length - 1; i > 0; i--) {
        const j = Math.floor(rng() * (i + 1));
        [colVals[i], colVals[j]] = [colVals[j], colVals[i]];
      }
      for (let i = 0; i < permX.length; i++) permX[i][f] = colVals[i];

      const permProbs = permX.map((x) => {
        const pLr = predictLogistic(this.lrModel, x);
        const pDt = predictTree(this.dtModel, x);
        const pRf = mean(this.rfModels.map((t) => predictTree(t, x)));
        const pGb = predictBoosted(this.gbModel, x);
        const pXgb = predictBoosted(this.xgbModel, x);
        return 0.10 * pLr + 0.05 * pDt + 0.25 * pRf + 0.28 * pGb + 0.32 * pXgb;
      });
      const permMetric = computeMetrics(yTest, permProbs, 'perm', 'perm');
      const drop = Math.max(0.002, baseAuc - permMetric.roc_auc + Math.abs(this.lrModel.weights[f] || 0) * 0.015);
      rawImportances.push({
        feature: this.preprocessor.featureNames[f],
        label: this.preprocessor.featureLabels[f],
        score: drop,
      });
    }
    const totalImp = rawImportances.reduce((s, x) => s + x.score, 0) || 1;
    this.featureImportance = rawImportances
      .map((item) => ({
        feature: item.feature,
        label: item.label,
        importance: Number(((item.score / totalImp) * 100).toFixed(2)),
      }))
      .sort((a, b) => b.importance - a.importance)
      .slice(0, 8);

    const defaults = rows.filter((r) => r.loan_status === 1).length;
    this.datasetSummary = {
      total_records: rows.length,
      train_records: trainRows.length,
      test_records: testRows.length,
      default_count: defaults,
      repaid_count: rows.length - defaults,
      default_rate: Number((defaults / rows.length).toFixed(4)),
      missing_values_imputed: missingCount,
      outliers_capped: outlierCount,
      feature_count: featureNames.length,
    };

    this.isTrained = true;

    // Persist real evaluation output to disk
    fs.mkdirSync(path.dirname(this.evalOutPath), { recursive: true });
    fs.writeFileSync(
      this.evalOutPath,
      JSON.stringify(
        {
          generated_at: new Date().toISOString(),
          dataset_summary: this.datasetSummary,
          models: this.metrics,
          feature_importance: this.featureImportance,
        },
        null,
        2
      )
    );
  }

  public predict(input: LoanInput): PredictionOutput {
    if (!this.isTrained) {
      this.train();
    }

    const preprocessingNotes: string[] = [];
    let inc = input.applicant_income;
    if (inc === null || Number.isNaN(inc) || inc <= 0) {
      inc = this.preprocessor.medians.applicant_income;
      preprocessingNotes.push(`Missing/invalid income imputed to dataset median ($${inc.toLocaleString()}).`);
    }
    let outOfDistCount = 0;
    if (inc > this.preprocessor.iqrBounds.applicant_income[1] || inc < this.preprocessor.iqrBounds.applicant_income[0]) {
      outOfDistCount++;
      preprocessingNotes.push(`Income ($${inc.toLocaleString()}) falls outside training IQR bounds and was winsorized.`);
      inc = clamp(inc, this.preprocessor.iqrBounds.applicant_income[0], this.preprocessor.iqrBounds.applicant_income[1]);
    }

    let loan = input.loan_amount;
    if (loan === null || Number.isNaN(loan) || loan <= 0) {
      loan = this.preprocessor.medians.loan_amount;
      preprocessingNotes.push(`Missing/invalid loan amount imputed to dataset median ($${loan.toLocaleString()}).`);
    }
    if (loan > this.preprocessor.iqrBounds.loan_amount[1] || loan < this.preprocessor.iqrBounds.loan_amount[0]) {
      outOfDistCount++;
      preprocessingNotes.push(`Loan amount ($${loan.toLocaleString()}) exceeds training IQR upper bound and was capped.`);
      loan = clamp(loan, this.preprocessor.iqrBounds.loan_amount[0], this.preprocessor.iqrBounds.loan_amount[1]);
    }

    let term = input.loan_term;
    if (term === null || Number.isNaN(term) || term <= 0) {
      term = this.preprocessor.medians.loan_term;
      preprocessingNotes.push(`Missing loan term defaulted to ${term} months.`);
    }

    let ch = input.credit_history;
    if (ch === null || Number.isNaN(ch) || (ch !== 0 && ch !== 1)) {
      ch = this.preprocessor.modes.credit_history;
      preprocessingNotes.push(`Missing credit history imputed to mode (${ch}).`);
    }

    let obl = input.existing_obligations;
    if (obl === null || Number.isNaN(obl) || obl < 0) {
      obl = this.preprocessor.medians.existing_obligations;
      preprocessingNotes.push(`Missing obligations imputed to median ($${obl.toLocaleString()}/mo).`);
    }
    if (obl > this.preprocessor.iqrBounds.existing_obligations[1]) {
      outOfDistCount++;
      preprocessingNotes.push(`Existing obligations capped at IQR ceiling ($${Math.round(this.preprocessor.iqrBounds.existing_obligations[1]).toLocaleString()}/mo).`);
      obl = clamp(obl, 0, this.preprocessor.iqrBounds.existing_obligations[1]);
    }

    const emp = input.employment_status && EMPLOYMENT_LEVELS.includes(input.employment_status)
      ? input.employment_status
      : this.preprocessor.modes.employment_status;
    const edu = input.education && EDUCATION_LEVELS.includes(input.education)
      ? input.education
      : this.preprocessor.modes.education;
    const mar = input.marital_status && MARITAL_LEVELS.includes(input.marital_status)
      ? input.marital_status
      : this.preprocessor.modes.marital_status;
    const prop = input.property_area && PROPERTY_LEVELS.includes(input.property_area)
      ? input.property_area
      : this.preprocessor.modes.property_area;

    const monthlyIncome = Math.max(inc / 12, 1);
    const monthlyInstallment = loan / Math.max(term, 1);
    const dti = (obl + monthlyInstallment) / monthlyIncome;
    const lti = loan / Math.max(inc, 1);

    const rawVec = [
      inc,
      loan,
      term,
      ch,
      obl,
      dti,
      lti,
      monthlyInstallment,
      ...EMPLOYMENT_LEVELS.map((e) => (emp === e ? 1 : 0)),
      ...EDUCATION_LEVELS.map((e) => (edu === e ? 1 : 0)),
      ...MARITAL_LEVELS.map((m) => (mar === m ? 1 : 0)),
      ...PROPERTY_LEVELS.map((p) => (prop === p ? 1 : 0)),
    ];

    const scaledVec = rawVec.map((v, j) =>
      j < 8 ? (v - this.preprocessor.scalerMeans[j]) / this.preprocessor.scalerStds[j] : v
    );

    const pLr = predictLogistic(this.lrModel, scaledVec);
    const pDt = predictTree(this.dtModel, scaledVec);
    const pRf = mean(this.rfModels.map((t) => predictTree(t, scaledVec)));
    const pGb = predictBoosted(this.gbModel, scaledVec);
    const pXgb = predictBoosted(this.xgbModel, scaledVec);
    const pEns = 0.10 * pLr + 0.05 * pDt + 0.25 * pRf + 0.28 * pGb + 0.32 * pXgb;

    // Bootstrap ensemble probabilities (20 resampled models)
    const bootProbs = this.bootstrapModels.map((m) => predictBoosted(m, scaledVec)).sort((a, b) => a - b);
    const bootStd = stdDev(bootProbs);
    const ciLow = clamp(quantile(bootProbs, 0.05), 0, 1);
    const ciHigh = clamp(quantile(bootProbs, 0.95), 0, 1);

    // Inter-model disagreement across the 5 distinct algorithms
    const modelProbs = [pLr, pDt, pRf, pGb, pXgb];
    const modelDisagreement = stdDev(modelProbs);

    // Normalized Shannon Predictive Entropy (0 = totally certain 0 or 1, 1 = maximal ambiguity at 0.5)
    const pClip = clamp(pEns, 1e-6, 1 - 1e-6);
    const entropy = -(pClip * Math.log2(pClip) + (1 - pClip) * Math.log2(1 - pClip));

    // Composite Epistemic + Aleatoric Uncertainty Score in [0, 1]
    // Distinct from Default Probability: high P(default)=0.90 has LOW entropy and can have LOW uncertainty!
    const normBoot = clamp(bootStd / 0.14, 0, 1);
    const normDisagree = clamp(modelDisagreement / 0.18, 0, 1);
    const oodPenalty = outOfDistCount > 0 ? Math.min(0.22, outOfDistCount * 0.11) : 0;
    const uncertaintyScore = clamp(0.42 * normBoot + 0.33 * normDisagree + 0.25 * entropy + oodPenalty, 0.03, 0.98);
    const confidenceScore = clamp(1 - uncertaintyScore, 0.02, 0.97);

    const crossesBoundary = ciLow < 0.5 && ciHigh >= 0.5;
    const isUncertain = uncertaintyScore >= 0.42 || crossesBoundary || modelDisagreement >= 0.12;

    const uncertaintyLevel: PredictionOutput['uncertainty_level'] =
      uncertaintyScore >= 0.52 ? 'High Uncertainty' : uncertaintyScore >= 0.32 ? 'Moderate Uncertainty' : 'Low Uncertainty';

    // Explain WHY the prediction may be uncertain (grounded in actual numbers)
    const reasons: string[] = [];
    if (modelDisagreement >= 0.09) {
      const minP = Math.min(...modelProbs);
      const maxP = Math.max(...modelProbs);
      reasons.push(
        `Significant inter-model disagreement (${(modelDisagreement * 100).toFixed(1)}% std dev): base models span from ${(minP * 100).toFixed(1)}% to ${(maxP * 100).toFixed(1)}% default probability.`
      );
    }
    if (crossesBoundary) {
      reasons.push(
        `Bootstrap 90% predictive interval [${(ciLow * 100).toFixed(1)}%, ${(ciHigh * 100).toFixed(1)}%] straddles the 50.0% decision threshold.`
      );
    }
    if (pEns >= 0.35 && pEns <= 0.65) {
      reasons.push(
        `Borderline ensemble default probability (${(pEns * 100).toFixed(1)}%) yields high Shannon predictive entropy (${(entropy * 100).toFixed(1)}%).`
      );
    }
    if (ch === 0 && inc >= 75000) {
      reasons.push(
        `Conflicting profile signals: strong annual income ($${inc.toLocaleString()}) paired with adverse credit history.`
      );
    } else if (ch === 1 && dti > 0.48) {
      reasons.push(
        `Conflicting profile signals: clean credit history offset by elevated Debt-to-Income ratio (${(dti * 100).toFixed(1)}%).`
      );
    }
    if (outOfDistCount > 0) {
      reasons.push(
        `Out-of-distribution input values (${outOfDistCount} feature(s) capped by IQR bounds) reduce training-data density.`
      );
    }
    if (reasons.length === 0) {
      reasons.push(
        `Strong consensus across all 5 base algorithms (disagreement ${(modelDisagreement * 100).toFixed(1)}%) and tight bootstrap interval [${(ciLow * 100).toFixed(1)}%, ${(ciHigh * 100).toFixed(1)}%].`
      );
    }

    // Risk Classification combining Default Probability AND Uncertainty
    let riskCategory: PredictionOutput['risk_category'];
    let recommendedAction: string;
    if (pEns >= 0.60) {
      riskCategory = 'High Risk';
      recommendedAction = isUncertain
        ? 'High Default Risk with Uncertainty — Escalate to Senior Credit Committee'
        : 'High Default Risk — Decline Unsecured Facility or Require Full Collateral';
    } else if (pEns >= 0.30 || isUncertain) {
      riskCategory = 'Medium Risk';
      recommendedAction = isUncertain
        ? 'Uncertain / Borderline Case — Route to Manual Underwriting & Income Verification'
        : 'Moderate Risk — Conditional Approval with Adjusted Interest Tier';
    } else {
      riskCategory = 'Low Risk';
      recommendedAction = 'Low Default Risk & High Model Consensus — Eligible for Standard Approval';
    }

    const contributions: PredictionOutput['feature_contributions'] = [
      {
        factor: 'Credit History',
        impact: ch === 1 ? 'Clean repayment record' : 'Prior delinquency recorded',
        direction: ch === 1 ? 'protective' : 'risk',
      },
      {
        factor: 'Debt-to-Income Ratio',
        impact: `${(dti * 100).toFixed(1)}% monthly obligation burden`,
        direction: dti > 0.42 ? 'risk' : 'protective',
      },
      {
        factor: 'Loan-to-Income Ratio',
        impact: `${lti.toFixed(2)}x annual income requested`,
        direction: lti > 0.55 ? 'risk' : 'protective',
      },
      {
        factor: 'Employment & Stability',
        impact: `${emp} · ${term}-month repayment horizon`,
        direction: emp === 'Unemployed' || emp === 'Freelancer' ? 'risk' : 'protective',
      },
    ];

    return {
      prediction: pEns >= 0.5 ? 'Likely to Default' : 'Likely to Repay',
      default_probability: Number(pEns.toFixed(4)),
      repayment_probability: Number((1 - pEns).toFixed(4)),
      confidence_score: Number(confidenceScore.toFixed(4)),
      uncertainty_score: Number(uncertaintyScore.toFixed(4)),
      bootstrap_std: Number(bootStd.toFixed(4)),
      model_disagreement: Number(modelDisagreement.toFixed(4)),
      entropy_score: Number(entropy.toFixed(4)),
      ci_low: Number(ciLow.toFixed(4)),
      ci_high: Number(ciHigh.toFixed(4)),
      is_uncertain: isUncertain,
      uncertainty_level: uncertaintyLevel,
      uncertainty_reasons: reasons,
      risk_category: riskCategory,
      recommended_action: recommendedAction,
      dti_ratio: Number(dti.toFixed(4)),
      lti_ratio: Number(lti.toFixed(4)),
      monthly_installment: Number(monthlyInstallment.toFixed(2)),
      preprocessing_notes: preprocessingNotes,
      model_breakdown: {
        logistic_regression: Number(pLr.toFixed(4)),
        decision_tree: Number(pDt.toFixed(4)),
        random_forest: Number(pRf.toFixed(4)),
        gradient_boosting: Number(pGb.toFixed(4)),
        xgboost: Number(pXgb.toFixed(4)),
        soft_voting_ensemble: Number(pEns.toFixed(4)),
      },
      feature_contributions: contributions,
    };
  }
}
