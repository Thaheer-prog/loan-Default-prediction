document.addEventListener("DOMContentLoaded", () => {
  const historyFilterInput = document.getElementById("historySearchInput");
  if (historyFilterInput) {
    historyFilterInput.addEventListener("input", () => {
      const term = historyFilterInput.value.toLowerCase();
      document.querySelectorAll("#historyTable tbody tr").forEach((row) => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(term) ? "" : "none";
      });
    });
  }

  document.querySelectorAll("[data-preset]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const preset = JSON.parse(btn.getAttribute("data-preset") || "{}");
      Object.entries(preset).forEach(([key, val]) => {
        const el = document.querySelector(`[name="${key}"]`);
        if (el) el.value = val;
      });
    });
  });
});
