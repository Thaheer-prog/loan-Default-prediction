"""
Automated Unit & Integration Tests for Uncertainty-Aware Loan Default Prediction.
Tests SQLite database operations, dataset integrity, schema constraints, and Flask endpoints (when installed).
"""

import csv
import os
import tempfile
import unittest

from database.db import (
    delete_prediction,
    get_all_predictions,
    get_dashboard_statistics,
    get_prediction_by_id,
    init_db,
    insert_prediction,
)


class TestLoanDefaultDatabaseAndDataset(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp_dir = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.tmp_dir.name, "test_loan.db")
        init_db(self.db_path)

    def tearDown(self) -> None:
        self.tmp_dir.cleanup()

    def test_dataset_exists_and_valid(self) -> None:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        csv_path = os.path.join(base_dir, "dataset", "loan_data.csv")
        self.assertTrue(os.path.exists(csv_path))
        with open(csv_path, "r", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        self.assertEqual(len(rows), 1200)
        self.assertIn("loan_status", rows[0])
        self.assertIn("existing_obligations", rows[0])

    def test_sqlite_crud_and_statistics(self) -> None:
        sample = {
            "application_ref": "APP-TEST-001",
            "applicant_name": "Test Borrower",
            "applicant_income": 75000.0,
            "loan_amount": 25000.0,
            "loan_term": 36,
            "credit_history": 1,
            "employment_status": "Salaried",
            "education": "Graduate",
            "marital_status": "Married",
            "property_area": "Urban",
            "existing_obligations": 650.0,
            "dti_ratio": 0.215,
            "lti_ratio": 0.333,
            "prediction": "Likely to Repay",
            "default_probability": 0.145,
            "confidence_score": 0.86,
            "uncertainty_score": 0.14,
            "bootstrap_std": 0.032,
            "model_disagreement": 0.041,
            "entropy_score": 0.59,
            "ci_low": 0.09,
            "ci_high": 0.21,
            "is_uncertain": False,
            "uncertainty_reasons": ["Strong consensus across all base models."],
            "model_breakdown": {"soft_voting_ensemble": 0.145},
            "risk_category": "Low Risk",
            "preprocessing_notes": [],
        }

        row_id = insert_prediction(sample, db_path=self.db_path)
        self.assertGreater(row_id, 0)

        fetched = get_prediction_by_id(row_id, db_path=self.db_path)
        self.assertIsNotNone(fetched)
        self.assertEqual(fetched["application_ref"], "APP-TEST-001")
        self.assertFalse(fetched["is_uncertain"])

        all_rows = get_all_predictions(db_path=self.db_path)
        self.assertEqual(len(all_rows), 1)

        stats = get_dashboard_statistics(db_path=self.db_path)
        self.assertEqual(stats["total_applications"], 1)
        self.assertEqual(stats["approved_predictions"], 1)
        self.assertEqual(stats["risk_distribution"]["low"], 1)

        deleted = delete_prediction(row_id, db_path=self.db_path)
        self.assertTrue(deleted)
        self.assertEqual(len(get_all_predictions(db_path=self.db_path)), 0)


if __name__ == "__main__":
    unittest.main()
