-- SQLite Schema for Uncertainty-Aware Ensemble Loan Default Prediction
CREATE TABLE IF NOT EXISTS loan_predictions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_ref TEXT NOT NULL UNIQUE,
    applicant_name TEXT NOT NULL DEFAULT 'Applicant',
    applicant_income REAL NOT NULL,
    loan_amount REAL NOT NULL,
    loan_term INTEGER NOT NULL,
    credit_history INTEGER NOT NULL CHECK (credit_history IN (0, 1)),
    employment_status TEXT NOT NULL,
    education TEXT NOT NULL,
    marital_status TEXT NOT NULL,
    property_area TEXT NOT NULL,
    existing_obligations REAL NOT NULL,
    dti_ratio REAL NOT NULL,
    lti_ratio REAL NOT NULL,
    prediction TEXT NOT NULL CHECK (prediction IN ('Likely to Repay', 'Likely to Default')),
    default_probability REAL NOT NULL,
    confidence_score REAL NOT NULL,
    uncertainty_score REAL NOT NULL,
    bootstrap_std REAL NOT NULL,
    model_disagreement REAL NOT NULL,
    entropy_score REAL NOT NULL,
    ci_low REAL NOT NULL,
    ci_high REAL NOT NULL,
    is_uncertain INTEGER NOT NULL CHECK (is_uncertain IN (0, 1)),
    uncertainty_reasons TEXT NOT NULL,
    model_breakdown TEXT NOT NULL,
    risk_category TEXT NOT NULL CHECK (risk_category IN ('Low Risk', 'Medium Risk', 'High Risk')),
    preprocessing_notes TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_loan_predictions_created_at ON loan_predictions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_loan_predictions_risk ON loan_predictions(risk_category);
