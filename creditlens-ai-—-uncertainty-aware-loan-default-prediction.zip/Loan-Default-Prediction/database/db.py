"""
SQLite Database Management Module for Uncertainty-Aware Loan Default Prediction.
Uses Python's standard library sqlite3 with parameterized queries.
"""

import json
import os
import sqlite3
from typing import Any, Dict, List, Optional


BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_DB_PATH = os.path.join(BASE_DIR, "database", "loan_default.db")
SCHEMA_PATH = os.path.join(BASE_DIR, "database", "schema.sql")


def get_connection(db_path: str = DEFAULT_DB_PATH) -> sqlite3.Connection:
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(db_path: str = DEFAULT_DB_PATH) -> None:
    with get_connection(db_path) as conn:
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            conn.executescript(f.read())
        conn.commit()


def insert_prediction(record: Dict[str, Any], db_path: str = DEFAULT_DB_PATH) -> int:
    sql = """
    INSERT INTO loan_predictions (
        application_ref, applicant_name, applicant_income, loan_amount, loan_term,
        credit_history, employment_status, education, marital_status, property_area,
        existing_obligations, dti_ratio, lti_ratio, prediction, default_probability,
        confidence_score, uncertainty_score, bootstrap_std, model_disagreement,
        entropy_score, ci_low, ci_high, is_uncertain, uncertainty_reasons,
        model_breakdown, risk_category, preprocessing_notes
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """
    params = (
        record["application_ref"],
        record["applicant_name"],
        float(record["applicant_income"]),
        float(record["loan_amount"]),
        int(record["loan_term"]),
        int(record["credit_history"]),
        record["employment_status"],
        record["education"],
        record["marital_status"],
        record["property_area"],
        float(record["existing_obligations"]),
        float(record["dti_ratio"]),
        float(record["lti_ratio"]),
        record["prediction"],
        float(record["default_probability"]),
        float(record["confidence_score"]),
        float(record["uncertainty_score"]),
        float(record["bootstrap_std"]),
        float(record["model_disagreement"]),
        float(record["entropy_score"]),
        float(record["ci_low"]),
        float(record["ci_high"]),
        1 if record["is_uncertain"] else 0,
        json.dumps(record["uncertainty_reasons"]),
        json.dumps(record["model_breakdown"]),
        record["risk_category"],
        json.dumps(record.get("preprocessing_notes", [])),
    )
    with get_connection(db_path) as conn:
        cur = conn.execute(sql, params)
        conn.commit()
        return int(cur.lastrowid)


def _deserialize_row(row: sqlite3.Row) -> Dict[str, Any]:
    item = dict(row)
    item["is_uncertain"] = bool(item["is_uncertain"])
    item["uncertainty_reasons"] = json.loads(item["uncertainty_reasons"] or "[]")
    item["model_breakdown"] = json.loads(item["model_breakdown"] or "{}")
    item["preprocessing_notes"] = json.loads(item.get("preprocessing_notes") or "[]")
    return item


def get_all_predictions(db_path: str = DEFAULT_DB_PATH) -> List[Dict[str, Any]]:
    with get_connection(db_path) as conn:
        rows = conn.execute(
            "SELECT * FROM loan_predictions ORDER BY datetime(created_at) DESC, id DESC"
        ).fetchall()
    return [_deserialize_row(r) for r in rows]


def get_prediction_by_id(record_id: int, db_path: str = DEFAULT_DB_PATH) -> Optional[Dict[str, Any]]:
    with get_connection(db_path) as conn:
        row = conn.execute("SELECT * FROM loan_predictions WHERE id = ?", (record_id,)).fetchone()
    return _deserialize_row(row) if row else None


def delete_prediction(record_id: int, db_path: str = DEFAULT_DB_PATH) -> bool:
    with get_connection(db_path) as conn:
        cur = conn.execute("DELETE FROM loan_predictions WHERE id = ?", (record_id,))
        conn.commit()
        return cur.rowcount > 0


def get_dashboard_statistics(db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    records = get_all_predictions(db_path)
    total = len(records)
    approved = sum(1 for r in records if r["prediction"] == "Likely to Repay")
    defaulted = sum(1 for r in records if r["prediction"] == "Likely to Default")
    uncertain = sum(1 for r in records if r["is_uncertain"])
    low_risk = sum(1 for r in records if r["risk_category"] == "Low Risk")
    med_risk = sum(1 for r in records if r["risk_category"] == "Medium Risk")
    high_risk = sum(1 for r in records if r["risk_category"] == "High Risk")

    avg_prob = sum(r["default_probability"] for r in records) / total if total else 0.0
    avg_unc = sum(r["uncertainty_score"] for r in records) / total if total else 0.0

    return {
        "total_applications": total,
        "approved_predictions": approved,
        "default_predictions": defaulted,
        "uncertain_predictions": uncertain,
        "avg_default_probability": round(avg_prob, 4),
        "avg_uncertainty_score": round(avg_unc, 4),
        "risk_distribution": {
            "low": low_risk,
            "medium": med_risk,
            "high": high_risk,
        },
    }
