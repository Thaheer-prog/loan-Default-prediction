"""
Synthetic Demonstration Dataset Generator for Uncertainty-Aware Loan Default Prediction.
Generates 1,200 realistic retail loan applications with controlled missing values and outliers
so preprocessing (imputation, outlier capping, categorical encoding, scaling) is genuinely exercised.

NOTE: Clearly labelled synthetic demonstration dataset for educational prototype use only.
"""

import csv
import math
import os
import random

SEED = 42
NUM_RECORDS = 1200


def clamp(val: float, low: float, high: float) -> float:
    return max(low, min(high, val))


def sigmoid(z: float) -> float:
    if z >= 0:
        return 1.0 / (1.0 + math.exp(-z))
    exp_z = math.exp(z)
    return exp_z / (1.0 + exp_z)


def generate_dataset(output_path: str) -> None:
    rng = random.Random(SEED)
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    employment_choices = ["Salaried", "Self-Employed", "Business Owner", "Freelancer", "Unemployed"]
    employment_weights = [0.54, 0.18, 0.14, 0.09, 0.05]

    education_choices = ["Graduate", "Post-Graduate", "Undergraduate", "High School"]
    education_weights = [0.46, 0.24, 0.18, 0.12]

    marital_choices = ["Married", "Single", "Divorced"]
    marital_weights = [0.58, 0.34, 0.08]

    property_choices = ["Urban", "Semiurban", "Rural"]
    property_weights = [0.38, 0.37, 0.25]

    term_choices = [12, 24, 36, 48, 60, 84, 120]
    term_weights = [0.06, 0.12, 0.28, 0.16, 0.22, 0.10, 0.06]

    headers = [
        "application_id",
        "applicant_income",
        "loan_amount",
        "loan_term",
        "credit_history",
        "employment_status",
        "education",
        "marital_status",
        "property_area",
        "existing_obligations",
        "loan_status",
    ]

    rows = []
    default_count = 0

    for i in range(1, NUM_RECORDS + 1):
        app_id = f"LN-{2025000 + i}"
        employment = rng.choices(employment_choices, weights=employment_weights, k=1)[0]
        education = rng.choices(education_choices, weights=education_weights, k=1)[0]
        marital = rng.choices(marital_choices, weights=marital_weights, k=1)[0]
        prop_area = rng.choices(property_choices, weights=property_weights, k=1)[0]
        term = rng.choices(term_choices, weights=term_weights, k=1)[0]

        # Income distribution conditioned on employment & education (annual USD)
        base_income = 52000.0
        if employment == "Business Owner":
            base_income = 84000.0
        elif employment == "Salaried":
            base_income = 64000.0
        elif employment == "Self-Employed":
            base_income = 58000.0
        elif employment == "Freelancer":
            base_income = 47000.0
        elif employment == "Unemployed":
            base_income = 19000.0

        if education == "Post-Graduate":
            base_income *= 1.24
        elif education == "Graduate":
            base_income *= 1.08
        elif education == "High School":
            base_income *= 0.80

        income = round(clamp(rng.lognormvariate(math.log(base_income), 0.38), 12000.0, 320000.0), 2)

        # Credit history: 1 = clean history, 0 = prior delinquency/missed payments
        ch_prob = 0.83
        if employment == "Unemployed":
            ch_prob = 0.48
        elif employment == "Freelancer":
            ch_prob = 0.72
        credit_history = 1 if rng.random() < ch_prob else 0

        # Loan amount correlated loosely with income and property area
        income_mult = rng.uniform(0.18, 0.92)
        if prop_area == "Urban":
            income_mult *= 1.15
        loan_amount = round(clamp(income * income_mult, 3000.0, 185000.0), 2)

        # Existing monthly financial obligations (USD/month)
        monthly_income = income / 12.0
        obl_ratio = rng.betavariate(2.0, 5.2) * 0.58
        if credit_history == 0:
            obl_ratio += rng.uniform(0.05, 0.16)
        existing_obligations = round(clamp(monthly_income * obl_ratio, 0.0, monthly_income * 0.78), 2)

        # Latent default risk log-odds (realistic non-linear + interaction structure)
        monthly_installment = loan_amount / max(term, 1)
        dti = (existing_obligations + monthly_installment) / max(monthly_income, 1.0)
        lti = loan_amount / max(income, 1.0)

        logit = -2.25
        # Strong credit history penalty
        if credit_history == 0:
            logit += 2.35
        # Debt-to-Income non-linear effect
        logit += 2.65 * max(0.0, dti - 0.30)
        if dti > 0.55:
            logit += 0.95
        # Loan-to-Income ratio
        logit += 1.15 * max(0.0, lti - 0.45)
        # Employment effects
        if employment == "Unemployed":
            logit += 1.45
        elif employment == "Freelancer":
            logit += 0.42
        elif employment == "Business Owner" and lti > 0.7:
            logit += 0.35
        elif employment == "Salaried":
            logit -= 0.25
        # Property area & education subtle effects
        if prop_area == "Rural":
            logit += 0.28
        elif prop_area == "Semiurban":
            logit -= 0.18
        if education == "High School":
            logit += 0.22
        elif education == "Post-Graduate":
            logit -= 0.18
        # Short-term heavy loans carry repayment pressure
        if term <= 24 and lti > 0.5:
            logit += 0.55
        # Conflicting region noise (creates realistic boundary cases for uncertainty!)
        logit += rng.gauss(0.0, 0.52)

        prob_default = sigmoid(logit)
        loan_status = 1 if rng.random() < prob_default else 0
        default_count += loan_status

        # Inject controlled missing values (~2.5%) & realistic outliers (~1.5%)
        inc_str = "" if rng.random() < 0.025 else str(income)
        if inc_str and rng.random() < 0.012:
            inc_str = str(round(income * rng.uniform(2.8, 4.2), 2))  # high-income outlier

        loan_str = "" if rng.random() < 0.020 else str(loan_amount)
        term_str = "" if rng.random() < 0.015 else str(term)
        ch_str = "" if rng.random() < 0.030 else str(credit_history)
        emp_str = "" if rng.random() < 0.020 else employment
        obl_str = "" if rng.random() < 0.025 else str(existing_obligations)

        rows.append([
            app_id,
            inc_str,
            loan_str,
            term_str,
            ch_str,
            emp_str,
            education,
            marital,
            prop_area,
            obl_str,
            loan_status,
        ])

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        writer.writerows(rows)

    print(
        f"Generated {NUM_RECORDS} loan records at {output_path} "
        f"(Defaults: {default_count}, Repaid: {NUM_RECORDS - default_count}, "
        f"Default Rate: {default_count / NUM_RECORDS:.2%})"
    )


if __name__ == "__main__":
    base_dir = os.path.dirname(os.path.abspath(__file__))
    generate_dataset(os.path.join(base_dir, "loan_data.csv"))
