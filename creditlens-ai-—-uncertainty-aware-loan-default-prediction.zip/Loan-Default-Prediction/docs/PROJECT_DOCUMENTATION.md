# Project Documentation: Uncertainty-Aware Ensemble Learning for Loan Default Prediction

**Project Type:** Individual B.Tech Project (Artificial Intelligence & Machine Learning)  
**Disclaimer:** Educational prototype using a synthetic demonstration dataset; not validated for real-world lending decisions.

---

## 1. Project Introduction
Credit risk assessment is a core operational decision in retail banking. Automated Machine Learning classifiers help screen loan applications rapidly, yet standard point-prediction pipelines expose only a single class label and probability score. When an applicant presents conflicting financial signals, sparse history, or extreme ratios, standard models still produce overconfident outputs. This project builds an end-to-end **Uncertainty-Aware Ensemble Learning** platform that outputs both default probability and calibrated predictive uncertainty.

## 2. Problem Statement
Traditional loan default prediction systems suffer from two critical limitations:
1. Single classifiers (e.g., standalone Logistic Regression or Decision Tree) struggle to balance bias and variance across non-linear borrower interactions.
2. Point probabilities conflate *risk* ($P(\text{Default})$) with *model certainty*. A 52% default probability might indicate true borderline risk or high epistemic ignorance due to conflicting signals and out-of-distribution features.

## 3. Objectives
- Collect and preprocess loan applicant features including income, loan amount, loan term, credit history, employment status, education, marital status, property area, and existing monthly obligations.
- Build a leak-free preprocessing pipeline handling missing values, IQR outlier capping, engineered financial ratios (DTI, LTI), categorical encoding, and feature scaling.
- Train and evaluate six models: Logistic Regression, Decision Tree, Random Forest, Gradient Boosting, XGBoost, and a Soft Voting Ensemble.
- Quantify uncertainty via Bootstrap ensembles, inter-model disagreement, and Shannon predictive entropy, and explain *why* flagged cases are uncertain.
- Persist predictions in SQLite, provide interactive dashboards and ROC/Confusion Matrix visualizations, and support HTML/CSV report exports.

## 4. Literature Review
- **Ensemble Methods in Credit Scoring**: Lessmann et al. (2015) benchmarked 41 classifiers across retail credit datasets and showed heterogeneous ensembles outperform individual linear and single-tree baselines.
- **Gradient Boosted Decision Trees (XGBoost)**: Chen & Guestrin (2016) introduced second-order gradient/Hessian tree boosting with L1/L2 regularization, becoming the industry standard for tabular credit risk modeling.
- **Uncertainty Quantification via Ensembles**: Lakshminarayanan et al. (2017) demonstrated that deep/bootstrap ensembles capture epistemic uncertainty via predictive variance across independently resampled models without requiring full Bayesian MCMC inference.

## 5. Existing System
Existing academic and baseline lending prototypes typically train a single classifier on clean data, render a binary "Approved / Rejected" verdict, and display the predicted probability as "confidence." They lack outlier guardrails, multi-model disagreement diagnostics, and human-review escalation triggers.

## 6. Proposed System
The proposed system integrates:
1. **Multi-Family Soft Voting Ensemble** combining linear (Logistic Regression), bagged (Random Forest), and boosted (Gradient Boosting, XGBoost) learners.
2. **Bootstrap Uncertainty Module** measuring epistemic spread ($\sigma_{\text{boot}}$) and 90% predictive intervals $[P_{\text{low}}, P_{\text{high}}]$.
3. **Model Disagreement & Entropy Module** measuring structural spread ($\sigma_{\text{models}}$) across model families and Shannon entropy $H(p)$.
4. **Three-Tier Risk Classification** (`Low Risk`, `Medium Risk`, `High Risk`) with explicit `Uncertain` escalation flags and textual explanations.

## 7. System Architecture
```
[Applicant Form / API]
        │
        ▼
[Validation & Preprocessing Pipeline]
  ├── Median/Mode Imputation (no data leakage)
  ├── IQR Outlier Winsorization (OOD audit)
  ├── Engineered Ratios: DTI, LTI, Monthly Installment
  └── One-Hot Encoding + StandardScaler
        │
        ├──────────────────────────────┐
        ▼                              ▼
[Soft Voting Ensemble]        [Bootstrap Ensemble + 5 Base Models]
  └── P(Default)                └── sigma_boot, sigma_models, H(p), 90% CI
        │                              │
        └──────────────┬───────────────┘
                       ▼
       [Risk Classifier & Uncertainty Explainer]
                       │
                       ▼
     [SQLite Storage + Interactive Dashboard + Reports]
```

## 8. Methodology
1. **Dataset Generation & Audit**: 1,200 realistic synthetic loan records (`dataset/loan_data.csv`) with 27.33% default rate, 166 missing values, and 52 outlier records to stress-test preprocessing.
2. **Stratified Split**: 80% training (959 records), 20% held-out testing (241 records).
3. **Training & Calibration**: All preprocessing statistics (medians, modes, IQR fences, scaler means/stds) are fit strictly on training folds.
4. **Uncertainty Scoring**:
   $$U = \text{clip}\left(0.42\cdot\frac{\sigma_{\text{boot}}}{0.14} + 0.33\cdot\frac{\sigma_{\text{models}}}{0.18} + 0.25\cdot H(p) + \text{OOD}_{\text{penalty}},\ 0.03,\ 0.98\right)$$
   $$\text{Confidence} = 1 - U$$

## 9. Algorithms Implemented
1. **Logistic Regression**: Linear log-odds baseline with L2 regularization.
2. **Decision Tree**: Interpretable Gini-impurity CART classifier (`max_depth=5`).
3. **Random Forest**: Bagged ensemble of randomized trees reducing variance.
4. **Gradient Boosting**: Stagewise additive trees minimizing binomial log-loss.
5. **XGBoost**: Second-order Newton-Raphson regularized tree boosting with column & row subsampling.
6. **Soft Voting Ensemble**: Weighted probability average across base learners.

## 10. Implementation
The repository ships both:
- A complete **Python/Flask** implementation (`app.py`, `train_model.py`, `database/db.py`, Bootstrap templates).
- A live interactive **Express + TypeScript ML Engine + React + SQLite** web platform running on port 3000 for immediate browser demonstration.

## 11. Results and Discussion
Actual evaluated metrics on the 241-record stratified held-out test set (`evaluation/metrics_live.json`):
- **Logistic Regression**: Accuracy 78.84%, Precision 66.67%, Recall 45.45%, F1 54.05%, ROC-AUC 77.35%
- **Decision Tree**: Accuracy 80.50%, Precision 67.92%, Recall 54.55%, F1 60.50%, ROC-AUC 79.19%
- **Random Forest**: Accuracy 80.50%, Precision 73.17%, Recall 45.45%, F1 56.07%, ROC-AUC 80.71%
- **Gradient Boosting**: Accuracy 78.42%, Precision 64.58%, Recall 46.97%, F1 54.39%, ROC-AUC 76.56%
- **XGBoost**: Accuracy 79.67%, Precision 68.09%, Recall 48.48%, F1 56.64%, ROC-AUC 76.48%
- **Soft Voting Ensemble**: Accuracy 80.50%, Precision 70.21%, Recall 50.00%, F1 58.41%, ROC-AUC 78.25%

Tree ensembles achieved stronger ROC-AUC and precision than the linear baseline, while the Soft Voting Ensemble stabilized probability calibration and exposed disagreements between linear and non-linear models on conflicting applicant profiles.

## 12. Testing
Automated tests verify dataset integrity, SQLite CRUD operations, missing-value imputation, negative/invalid input rejection, model loading, and endpoint responses (`tests/test_app.py`).

## 13. Advantages and Limitations
**Advantages:** Prevents blind automation on ambiguous cases; separates risk probability from confidence; preserves full SQLite auditability.  
**Limitations:** Trained on synthetic demonstration data; lacks longitudinal macroeconomic covariates and formal regulatory disparate-impact auditing.

## 14. Conclusion
Combining Soft Voting Ensembles with bootstrap variance and inter-model disagreement makes credit default prediction substantially more transparent and safe. Underwriters gain actionable visibility into *when* an AI prediction can be trusted and *why* borderline cases require human judgment.

## 15. Future Enhancements
- Conformal Prediction wrappers for distribution-free finite-sample coverage guarantees.
- SHAP force-plot integration per applicant.
- Automated drift monitoring via Population Stability Index (PSI).

## 16. References
1. Chen, T., & Guestrin, C. (2016). *XGBoost: A Scalable Tree Boosting System*. KDD.
2. Lakshminarayanan, B., Pritzel, A., & Blundell, C. (2017). *Simple and Scalable Predictive Uncertainty Estimation using Deep Ensembles*. NeurIPS.
3. Lessmann, S., et al. (2015). *Benchmarking state-of-the-art classification algorithms for credit scoring*. European Journal of Operational Research.
4. Pedregosa, F., et al. (2011). *Scikit-learn: Machine Learning in Python*. JMLR.
