export interface ModelMetric {
  model: string;
  key: string;
  accuracy: number;
  precision: number;
  recall: number;
  f1_score: number;
  roc_auc: number;
  confusion_matrix: [[number, number], [number, number]];
  roc_curve: { fpr: number; tpr: number }[];
}

export interface FeatureImportanceItem {
  feature: string;
  label: string;
  importance: number;
}

export interface DatasetSummary {
  total_records: number;
  train_records: number;
  test_records: number;
  default_count: number;
  repaid_count: number;
  default_rate: number;
  missing_values_imputed: number;
  outliers_capped: number;
  feature_count: number;
}

export interface StoredPredictionRecord {
  id: number;
  application_ref: string;
  applicant_name: string;
  applicant_income: number;
  loan_amount: number;
  loan_term: number;
  credit_history: number;
  employment_status: string;
  education: string;
  marital_status: string;
  property_area: string;
  existing_obligations: number;
  dti_ratio: number;
  lti_ratio: number;
  prediction: 'Likely to Repay' | 'Likely to Default';
  default_probability: number;
  confidence_score: number;
  uncertainty_score: number;
  bootstrap_std: number;
  model_disagreement: number;
  entropy_score: number;
  ci_low: number;
  ci_high: number;
  is_uncertain: boolean;
  uncertainty_reasons: string[];
  model_breakdown: Record<string, number>;
  risk_category: 'Low Risk' | 'Medium Risk' | 'High Risk';
  preprocessing_notes: string[];
  created_at: string;
}

export interface PredictionOutput {
  prediction: 'Likely to Repay' | 'Likely to Default';
  default_probability: number;
  repayment_probability: number;
  confidence_score: number;
  uncertainty_score: number;
  bootstrap_std: number;
  model_disagreement: number;
  entropy_score: number;
  ci_low: number;
  ci_high: number;
  is_uncertain: boolean;
  uncertainty_level: 'Low Uncertainty' | 'Moderate Uncertainty' | 'High Uncertainty';
  uncertainty_reasons: string[];
  risk_category: 'Low Risk' | 'Medium Risk' | 'High Risk';
  recommended_action: string;
  dti_ratio: number;
  lti_ratio: number;
  monthly_installment: number;
  preprocessing_notes: string[];
  model_breakdown: {
    logistic_regression: number;
    decision_tree: number;
    random_forest: number;
    gradient_boosting: number;
    xgboost: number;
    soft_voting_ensemble: number;
  };
  feature_contributions: { factor: string; impact: string; direction: 'risk' | 'protective' }[];
}

export interface DashboardPayload {
  stats: {
    total_applications: number;
    approved_predictions: number;
    default_predictions: number;
    uncertain_predictions: number;
    avg_default_probability: number;
    avg_uncertainty_score: number;
    total_loan_volume: number;
    risk_distribution: {
      low: number;
      medium: number;
      high: number;
    };
  };
  recent: StoredPredictionRecord[];
  all_records: StoredPredictionRecord[];
  dataset_summary: DatasetSummary;
  ensemble_auc: number;
}
