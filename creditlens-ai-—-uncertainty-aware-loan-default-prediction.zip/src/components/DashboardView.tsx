import React from 'react';
import { Download, ArrowUpRight } from 'lucide-react';
import { DashboardPayload, FeatureImportanceItem, StoredPredictionRecord } from '../types';
import { FeatureImportanceChart, RiskDistributionBar, UncertaintyScatterChart } from './Charts';
import { NavTab } from './HomeView';

export function DashboardView({
  dashboard,
  featureImportance,
  loading,
  onNavigate,
  onSelectRecord,
}: {
  dashboard: DashboardPayload | null;
  featureImportance: FeatureImportanceItem[];
  loading: boolean;
  onNavigate: (tab: NavTab) => void;
  onSelectRecord: (rec: StoredPredictionRecord) => void;
}) {
  if (loading || !dashboard) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="bg-white border border-slate-200 rounded-xl p-5 h-28 animate-pulse" />
          ))}
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-6 h-80 animate-pulse" />
      </div>
    );
  }

  const { stats, recent, all_records } = dashboard;

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Total Applications</div>
          <div className="mt-2 text-3xl font-bold font-mono tabular-nums text-slate-900">
            {stats.total_applications}
          </div>
          <div className="mt-1 text-xs text-slate-500 font-mono tabular-nums">
            Volume ${Math.round(stats.total_loan_volume).toLocaleString()}
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Repayment Predictions</div>
          <div className="mt-2 text-3xl font-bold font-mono tabular-nums text-emerald-700">
            {stats.approved_predictions}
          </div>
          <div className="mt-1 text-xs text-slate-500 font-mono tabular-nums">
            {stats.total_applications > 0
              ? `${((stats.approved_predictions / stats.total_applications) * 100).toFixed(1)}% of portfolio`
              : '0.0%'}
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Default Predictions</div>
          <div className="mt-2 text-3xl font-bold font-mono tabular-nums text-rose-700">
            {stats.default_predictions}
          </div>
          <div className="mt-1 text-xs text-slate-500 font-mono tabular-nums">
            Avg P(Default) {(stats.avg_default_probability * 100).toFixed(1)}%
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5">
          <div className="text-xs font-medium text-slate-500">Uncertain Cases Flagged</div>
          <div className="mt-2 text-3xl font-bold font-mono tabular-nums text-amber-700">
            {stats.uncertain_predictions}
          </div>
          <div className="mt-1 text-xs text-slate-500 font-mono tabular-nums">
            Avg Uncertainty {(stats.avg_uncertainty_score * 100).toFixed(1)}%
          </div>
        </div>
      </div>

      {/* Main Analytics Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
            <div>
              <h2 className="text-base font-semibold text-slate-900">
                Probability vs. Epistemic Uncertainty Map
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Applications above the 42% uncertainty line or near the 50% probability threshold require manual underwriting.
              </p>
            </div>
          </div>
          {all_records.length > 0 ? (
            <UncertaintyScatterChart records={all_records} onSelect={onSelectRecord} />
          ) : (
            <div className="py-12 text-center text-sm text-slate-500">
              No predictions stored yet. Submit a loan application to populate the chart.
            </div>
          )}
        </div>

        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-6">
            <h2 className="text-base font-semibold text-slate-900 mb-1">Risk Tier Distribution</h2>
            <p className="text-xs text-slate-500 mb-4">
              Combines predicted default probability with uncertainty guardrails.
            </p>
            <RiskDistributionBar
              low={stats.risk_distribution.low}
              medium={stats.risk_distribution.medium}
              high={stats.risk_distribution.high}
            />
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-6">
            <h2 className="text-base font-semibold text-slate-900 mb-1">Top Predictive Risk Drivers</h2>
            <p className="text-xs text-slate-500 mb-4">
              Permutation feature importance measured on the Soft Voting Ensemble.
            </p>
            <FeatureImportanceChart items={featureImportance.slice(0, 5)} />
          </div>
        </div>
      </div>

      {/* Recent Applications Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-slate-900">Recent Underwriting Assessments</h2>
            <p className="text-xs text-slate-500">Click any applicant row to inspect full uncertainty diagnostics or download a report.</p>
          </div>
          <div className="flex items-center gap-2">
            <a
              href="/api/reports/export-csv"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 whitespace-nowrap shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </a>
            <button
              type="button"
              onClick={() => onNavigate('history')}
              className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-blue-700 hover:text-blue-900 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>View All History</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-600">
                <th className="py-3 px-4">Application</th>
                <th className="py-3 px-4 text-right">Loan Amount</th>
                <th className="py-3 px-4 text-right">Default Prob</th>
                <th className="py-3 px-4 text-right">Confidence</th>
                <th className="py-3 px-4 text-right">Uncertainty</th>
                <th className="py-3 px-4">Risk Tier</th>
                <th className="py-3 px-4">Prediction</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {recent.map((r) => (
                <tr
                  key={r.id}
                  onClick={() => onSelectRecord(r)}
                  className="hover:bg-slate-50 cursor-pointer transition-colors"
                >
                  <td className="py-3 px-4">
                    <div className="font-medium text-slate-900">{r.applicant_name}</div>
                    <div className="text-xs text-slate-500 font-mono">
                      {r.application_ref} · {r.employment_status}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-800">
                    ${r.loan_amount.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-slate-900">
                    {(r.default_probability * 100).toFixed(1)}%
                  </td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                    {(r.confidence_score * 100).toFixed(1)}%
                  </td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums">
                    <span className={r.is_uncertain ? 'text-amber-700 font-semibold' : 'text-slate-600'}>
                      {(r.uncertainty_score * 100).toFixed(1)}%
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`text-xs font-semibold ${
                        r.risk_category === 'High Risk'
                          ? 'text-rose-700'
                          : r.risk_category === 'Medium Risk'
                          ? 'text-amber-700'
                          : 'text-emerald-700'
                      }`}
                    >
                      {r.risk_category}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-xs text-slate-700">
                    {r.prediction}
                    {r.is_uncertain ? ' (Uncertain)' : ''}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
