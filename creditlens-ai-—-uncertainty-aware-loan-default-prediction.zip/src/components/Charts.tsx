import React, { useState } from 'react';
import { FeatureImportanceItem, ModelMetric, StoredPredictionRecord } from '../types';

const MODEL_COLORS: Record<string, string> = {
  logistic_regression: '#64748b',
  decision_tree: '#0ea5e9',
  random_forest: '#16a34a',
  gradient_boosting: '#d97706',
  xgboost: '#4f46e5',
  soft_voting_ensemble: '#1d4ed8',
};

export function RocCurveChart({ models }: { models: ModelMetric[] }) {
  const [activeKey, setActiveKey] = useState<string | null>(null);
  const w = 520;
  const h = 320;
  const pad = { top: 20, right: 20, bottom: 42, left: 48 };
  const plotW = w - pad.left - pad.right;
  const plotH = h - pad.top - pad.bottom;

  const toX = (fpr: number) => pad.left + fpr * plotW;
  const toY = (tpr: number) => pad.top + (1 - tpr) * plotH;

  return (
    <div>
      <div className="w-full overflow-x-auto">
        <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-auto max-h-[340px]" role="img" aria-label="ROC Curve Comparison">
          {/* Grid lines */}
          {[0, 0.25, 0.5, 0.75, 1].map((v) => (
            <g key={v}>
              <line
                x1={pad.left}
                y1={toY(v)}
                x2={w - pad.right}
                y2={toY(v)}
                stroke="#e2e8f0"
                strokeWidth="1"
              />
              <line
                x1={toX(v)}
                y1={pad.top}
                x2={toX(v)}
                y2={h - pad.bottom}
                stroke="#e2e8f0"
                strokeWidth="1"
              />
              <text
                x={pad.left - 8}
                y={toY(v) + 4}
                textAnchor="end"
                className="fill-slate-500 text-[10px] font-mono"
              >
                {v.toFixed(2)}
              </text>
              <text
                x={toX(v)}
                y={h - pad.bottom + 16}
                textAnchor="middle"
                className="fill-slate-500 text-[10px] font-mono"
              >
                {v.toFixed(2)}
              </text>
            </g>
          ))}

          {/* Random baseline diagonal */}
          <line
            x1={toX(0)}
            y1={toY(0)}
            x2={toX(1)}
            y2={toY(1)}
            stroke="#94a3b8"
            strokeDasharray="4 4"
            strokeWidth="1.2"
          />

          {/* Model ROC Curves */}
          {models.map((m) => {
            const pts = m.roc_curve.map((pt) => `${toX(pt.fpr)},${toY(pt.tpr)}`).join(' ');
            const isHighlighted = activeKey === null || activeKey === m.key;
            const isEnsemble = m.key === 'soft_voting_ensemble';
            return (
              <polyline
                key={m.key}
                fill="none"
                stroke={MODEL_COLORS[m.key] || '#1d4ed8'}
                strokeWidth={activeKey === m.key || isEnsemble ? 2.6 : 1.7}
                strokeOpacity={isHighlighted ? 1 : 0.2}
                points={pts}
              />
            );
          })}

          {/* Axis labels */}
          <text
            x={pad.left + plotW / 2}
            y={h - 6}
            textAnchor="middle"
            className="fill-slate-600 text-[11px] font-medium"
          >
            False Positive Rate (1 - Specificity)
          </text>
          <text
            x={14}
            y={pad.top + plotH / 2}
            textAnchor="middle"
            transform={`rotate(-90 14 ${pad.top + plotH / 2})`}
            className="fill-slate-600 text-[11px] font-medium"
          >
            True Positive Rate (Recall)
          </text>
        </svg>
      </div>

      {/* Interactive Legend */}
      <div className="mt-4 flex flex-wrap gap-2">
        {models.map((m) => {
          const active = activeKey === m.key;
          return (
            <button
              key={m.key}
              type="button"
              onClick={() => setActiveKey(active ? null : m.key)}
              className={`inline-flex items-center gap-2 px-2.5 py-1.5 text-xs rounded-md border transition-colors whitespace-nowrap shrink-0 ${
                active
                  ? 'border-blue-600 bg-blue-50 text-slate-900 font-semibold'
                  : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              <span
                className="w-2.5 h-2.5 rounded-sm shrink-0"
                style={{ backgroundColor: MODEL_COLORS[m.key] || '#1d4ed8' }}
              />
              <span>{m.model}</span>
              <span className="font-mono text-slate-500">{m.roc_auc.toFixed(3)}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function ConfusionMatrixCard({ model }: { model: ModelMetric }) {
  const [[tn, fp], [fn, tp]] = model.confusion_matrix;
  const total = tn + fp + fn + tp || 1;
  const cells = [
    { label: 'True Negative (Repaid)', val: tn, pct: (tn / total) * 100, tone: 'bg-blue-50 text-blue-950 border-blue-200' },
    { label: 'False Positive (Type I)', val: fp, pct: (fp / total) * 100, tone: 'bg-amber-50 text-amber-950 border-amber-200' },
    { label: 'False Negative (Type II)', val: fn, pct: (fn / total) * 100, tone: 'bg-rose-50 text-rose-950 border-rose-200' },
    { label: 'True Positive (Default)', val: tp, pct: (tp / total) * 100, tone: 'bg-blue-600 text-white border-blue-700' },
  ];

  return (
    <div>
      <div className="grid grid-cols-2 gap-3">
        {cells.map((c) => (
          <div key={c.label} className={`rounded-lg border p-4 ${c.tone}`}>
            <div className="text-xs opacity-80">{c.label}</div>
            <div className="mt-1 flex items-baseline justify-between">
              <span className="text-2xl font-bold font-mono tabular-nums">{c.val}</span>
              <span className="text-xs font-mono tabular-nums opacity-85">{c.pct.toFixed(1)}%</span>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-3 flex items-center justify-between text-xs text-slate-500">
        <span>Test Set Support: {total} applications</span>
        <span className="font-mono tabular-nums">
          Accuracy {(model.accuracy * 100).toFixed(1)}% · F1 {(model.f1_score * 100).toFixed(1)}%
        </span>
      </div>
    </div>
  );
}

export function FeatureImportanceChart({ items }: { items: FeatureImportanceItem[] }) {
  const maxVal = Math.max(...items.map((i) => i.importance), 1);
  return (
    <div className="space-y-3">
      {items.map((item) => (
        <div key={item.feature}>
          <div className="flex items-center justify-between text-xs mb-1">
            <span className="font-medium text-slate-700">{item.label}</span>
            <span className="font-mono tabular-nums text-slate-600">{item.importance.toFixed(1)}%</span>
          </div>
          <div className="h-2 w-full bg-slate-100 rounded-sm overflow-hidden">
            <div
              className="h-full bg-blue-600 rounded-sm transition-all duration-300"
              style={{ width: `${(item.importance / maxVal) * 100}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

export function UncertaintyScatterChart({
  records,
  onSelect,
}: {
  records: StoredPredictionRecord[];
  onSelect?: (r: StoredPredictionRecord) => void;
}) {
  const [hovered, setHovered] = useState<StoredPredictionRecord | null>(null);
  const w = 520;
  const h = 290;
  const pad = { top: 20, right: 24, bottom: 40, left: 48 };
  const plotW = w - pad.left - pad.right;
  const plotH = h - pad.top - pad.bottom;

  const toX = (prob: number) => pad.left + prob * plotW;
  const toY = (unc: number) => pad.top + (1 - unc) * plotH;

  return (
    <div className="relative">
      <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-auto max-h-[300px]" role="img" aria-label="Default Probability vs Uncertainty Scatter Plot">
        {/* Uncertainty threshold band (U >= 0.42) */}
        <rect
          x={pad.left}
          y={pad.top}
          width={plotW}
          height={toY(0.42) - pad.top}
          fill="#fef3c7"
          fillOpacity="0.45"
        />

        {/* Grid lines */}
        {[0, 0.25, 0.5, 0.75, 1].map((v) => (
          <g key={v}>
            <line x1={pad.left} y1={toY(v)} x2={w - pad.right} y2={toY(v)} stroke="#e2e8f0" strokeWidth="1" />
            <line x1={toX(v)} y1={pad.top} x2={toX(v)} y2={h - pad.bottom} stroke="#e2e8f0" strokeWidth="1" />
            <text x={pad.left - 8} y={toY(v) + 4} textAnchor="end" className="fill-slate-500 text-[10px] font-mono">
              {Math.round(v * 100)}%
            </text>
            <text x={toX(v)} y={h - pad.bottom + 16} textAnchor="middle" className="fill-slate-500 text-[10px] font-mono">
              {Math.round(v * 100)}%
            </text>
          </g>
        ))}

        {/* 50% Decision Boundary & 42% Uncertainty Threshold */}
        <line x1={toX(0.5)} y1={pad.top} x2={toX(0.5)} y2={h - pad.bottom} stroke="#64748b" strokeDasharray="4 4" strokeWidth="1.2" />
        <line x1={pad.left} y1={toY(0.42)} x2={w - pad.right} y2={toY(0.42)} stroke="#d97706" strokeDasharray="4 4" strokeWidth="1.2" />

        <text x={w - pad.right - 6} y={pad.top + 14} textAnchor="end" className="fill-amber-800 text-[10px] font-medium">
          Uncertain Zone (Manual Review)
        </text>

        {/* Data points */}
        {records.map((r) => {
          const cx = toX(r.default_probability);
          const cy = toY(r.uncertainty_score);
          const fill =
            r.risk_category === 'High Risk' ? '#dc2626' : r.risk_category === 'Medium Risk' ? '#d97706' : '#16a34a';
          const isHov = hovered?.id === r.id;
          return (
            <circle
              key={r.id}
              cx={cx}
              cy={cy}
              r={isHov ? 7 : 5}
              fill={fill}
              fillOpacity={0.85}
              stroke="#ffffff"
              strokeWidth="1.5"
              className="cursor-pointer transition-all"
              onMouseEnter={() => setHovered(r)}
              onMouseLeave={() => setHovered(null)}
              onClick={() => onSelect && onSelect(r)}
            />
          );
        })}

        <text x={pad.left + plotW / 2} y={h - 6} textAnchor="middle" className="fill-slate-600 text-[11px] font-medium">
          Default Probability P(Default)
        </text>
        <text
          x={14}
          y={pad.top + plotH / 2}
          textAnchor="middle"
          transform={`rotate(-90 14 ${pad.top + plotH / 2})`}
          className="fill-slate-600 text-[11px] font-medium"
        >
          Uncertainty Score (U)
        </text>
      </svg>

      {hovered && (
        <div className="mt-2 rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-700 flex flex-wrap items-center justify-between gap-2">
          <span className="font-medium text-slate-900">
            {hovered.application_ref} · {hovered.applicant_name}
          </span>
          <span className="font-mono tabular-nums">
            P(Default) {(hovered.default_probability * 100).toFixed(1)}% · Uncertainty {(hovered.uncertainty_score * 100).toFixed(1)}% · {hovered.risk_category}
          </span>
        </div>
      )}
    </div>
  );
}

export function RiskDistributionBar({ low, medium, high }: { low: number; medium: number; high: number }) {
  const total = Math.max(1, low + medium + high);
  const rows = [
    { label: 'Low Risk (Standard Approval)', count: low, pct: (low / total) * 100, color: 'bg-emerald-600' },
    { label: 'Medium Risk / Uncertain Review', count: medium, pct: (medium / total) * 100, color: 'bg-amber-500' },
    { label: 'High Risk (Elevated Default)', count: high, pct: (high / total) * 100, color: 'bg-rose-600' },
  ];

  return (
    <div className="space-y-4">
      <div className="h-3.5 w-full rounded-sm overflow-hidden bg-slate-100 flex">
        {rows.map((r) =>
          r.count > 0 ? (
            <div
              key={r.label}
              className={`${r.color} h-full transition-all duration-300`}
              style={{ width: `${r.pct}%` }}
              title={`${r.label}: ${r.count}`}
            />
          ) : null
        )}
      </div>
      <div className="space-y-2.5">
        {rows.map((r) => (
          <div key={r.label} className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-sm ${r.color}`} />
              <span className="text-slate-700">{r.label}</span>
            </div>
            <span className="font-mono tabular-nums text-slate-900 font-medium">
              {r.count} ({r.pct.toFixed(1)}%)
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
