import React, { useState } from 'react';
import { AlertTriangle, CheckCircle2, Download, HelpCircle, RefreshCw } from 'lucide-react';
import { PredictionOutput, StoredPredictionRecord } from '../types';

interface FormState {
  applicant_name: string;
  applicant_income: string;
  loan_amount: string;
  loan_term: string;
  credit_history: string;
  employment_status: string;
  education: string;
  marital_status: string;
  property_area: string;
  existing_obligations: string;
}

const PRESETS: { label: string; data: FormState }[] = [
  {
    label: 'Strong Salaried Profile',
    data: {
      applicant_name: 'Vikram Sethi',
      applicant_income: '96000',
      loan_amount: '24000',
      loan_term: '48',
      credit_history: '1',
      employment_status: 'Salaried',
      education: 'Post-Graduate',
      marital_status: 'Married',
      property_area: 'Urban',
      existing_obligations: '600',
    },
  },
  {
    label: 'Uncertain Conflicting Profile',
    data: {
      applicant_name: 'Riya Chatterjee',
      applicant_income: '84000',
      loan_amount: '48000',
      loan_term: '36',
      credit_history: '0',
      employment_status: 'Salaried',
      education: 'Post-Graduate',
      marital_status: 'Single',
      property_area: 'Semiurban',
      existing_obligations: '1400',
    },
  },
  {
    label: 'High Default Risk Profile',
    data: {
      applicant_name: 'Manish Tiwari',
      applicant_income: '28000',
      loan_amount: '26000',
      loan_term: '24',
      credit_history: '0',
      employment_status: 'Unemployed',
      education: 'High School',
      marital_status: 'Single',
      property_area: 'Rural',
      existing_obligations: '950',
    },
  },
  {
    label: 'Missing Income / Outlier Test',
    data: {
      applicant_name: 'Devika Nair',
      applicant_income: '',
      loan_amount: '165000',
      loan_term: '60',
      credit_history: '1',
      employment_status: 'Business Owner',
      education: 'Graduate',
      marital_status: 'Married',
      property_area: 'Urban',
      existing_obligations: '2100',
    },
  },
];

export function PredictView({ onSaved }: { onSaved: () => void }) {
  const [form, setForm] = useState<FormState>(PRESETS[1].data);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<PredictionOutput | null>(null);
  const [savedRecord, setSavedRecord] = useState<StoredPredictionRecord | null>(null);

  const handleChange = (field: keyof FormState, val: string) => {
    setForm((prev) => ({ ...prev, [field]: val }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);

    try {
      const resp = await fetch('/api/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          applicant_name: form.applicant_name.trim() || 'Applicant',
          applicant_income: form.applicant_income === '' ? null : Number(form.applicant_income),
          loan_amount: form.loan_amount === '' ? null : Number(form.loan_amount),
          loan_term: form.loan_term === '' ? null : Number(form.loan_term),
          credit_history: form.credit_history === '' ? null : Number(form.credit_history),
          employment_status: form.employment_status,
          education: form.education,
          marital_status: form.marital_status,
          property_area: form.property_area,
          existing_obligations: form.existing_obligations === '' ? null : Number(form.existing_obligations),
          save: true,
        }),
      });

      const data = await resp.json();
      if (!resp.ok) {
        setError(data.error || 'Prediction request failed.');
      } else {
        setResult(data.prediction_result);
        setSavedRecord(data.record);
        onSaved();
      }
    } catch {
      setError('Network error while connecting to prediction service.');
    } finally {
      setSubmitting(false);
    }
  };

  const modelRows = result
    ? [
        { name: 'Logistic Regression', prob: result.model_breakdown.logistic_regression },
        { name: 'Decision Tree', prob: result.model_breakdown.decision_tree },
        { name: 'Random Forest', prob: result.model_breakdown.random_forest },
        { name: 'Gradient Boosting', prob: result.model_breakdown.gradient_boosting },
        { name: 'XGBoost', prob: result.model_breakdown.xgboost },
        { name: 'Soft Voting Ensemble', prob: result.model_breakdown.soft_voting_ensemble, primary: true },
      ]
    : [];

  return (
    <div className="space-y-6">
      {/* Quick-Fill Scenario Buttons */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <span className="text-xs font-medium text-slate-600">Load Demonstration Scenario:</span>
        <div className="flex flex-wrap gap-2">
          {PRESETS.map((p) => (
            <button
              key={p.label}
              type="button"
              onClick={() => {
                setForm(p.data);
                setError(null);
              }}
              className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-blue-50 hover:text-blue-800 border border-slate-200 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Application Form */}
        <form onSubmit={handleSubmit} className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">Loan Application Profile</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Leave numeric fields blank to verify automated median imputation during preprocessing.
            </p>
          </div>

          {error && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-800 font-medium">
              {error}
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Applicant Full Name</label>
            <input
              type="text"
              value={form.applicant_name}
              onChange={(e) => handleChange('applicant_name', e.target.value)}
              placeholder="e.g., Arjun Mehta"
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Annual Income (USD)</label>
              <input
                type="number"
                step="100"
                value={form.applicant_income}
                onChange={(e) => handleChange('applicant_income', e.target.value)}
                placeholder="Median imputed if blank"
                className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Loan Amount (USD)</label>
              <input
                type="number"
                step="100"
                value={form.loan_amount}
                onChange={(e) => handleChange('loan_amount', e.target.value)}
                placeholder="e.g., 25000"
                className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Loan Term (Months)</label>
              <select
                value={form.loan_term}
                onChange={(e) => handleChange('loan_term', e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                <option value="12">12 Months</option>
                <option value="24">24 Months</option>
                <option value="36">36 Months</option>
                <option value="48">48 Months</option>
                <option value="60">60 Months</option>
                <option value="84">84 Months</option>
                <option value="120">120 Months</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Existing Obligations ($/mo)</label>
              <input
                type="number"
                step="25"
                value={form.existing_obligations}
                onChange={(e) => handleChange('existing_obligations', e.target.value)}
                placeholder="Monthly debt payments"
                className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Credit History</label>
              <select
                value={form.credit_history}
                onChange={(e) => handleChange('credit_history', e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                <option value="1">1 — Clean Repayment History</option>
                <option value="0">0 — Prior Delinquency / Missed</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Employment Status</label>
              <select
                value={form.employment_status}
                onChange={(e) => handleChange('employment_status', e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                <option value="Salaried">Salaried</option>
                <option value="Self-Employed">Self-Employed</option>
                <option value="Business Owner">Business Owner</option>
                <option value="Freelancer">Freelancer</option>
                <option value="Unemployed">Unemployed</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Education</label>
              <select
                value={form.education}
                onChange={(e) => handleChange('education', e.target.value)}
                className="w-full px-2.5 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                <option value="Post-Graduate">Post-Graduate</option>
                <option value="Graduate">Graduate</option>
                <option value="Undergraduate">Undergraduate</option>
                <option value="High School">High School</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Marital Status</label>
              <select
                value={form.marital_status}
                onChange={(e) => handleChange('marital_status', e.target.value)}
                className="w-full px-2.5 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                <option value="Married">Married</option>
                <option value="Single">Single</option>
                <option value="Divorced">Divorced</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Property Area</label>
              <select
                value={form.property_area}
                onChange={(e) => handleChange('property_area', e.target.value)}
                className="w-full px-2.5 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                <option value="Urban">Urban</option>
                <option value="Semiurban">Semiurban</option>
                <option value="Rural">Rural</option>
              </select>
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={submitting}
              className="w-full inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-blue-700 hover:bg-blue-800 disabled:opacity-60 text-white text-sm font-semibold rounded-lg transition-colors cursor-pointer"
            >
              {submitting ? <RefreshCw className="w-4 h-4 animate-spin" /> : null}
              <span>{submitting ? 'Running Ensemble & Bootstrap Sampling...' : 'Predict Default & Estimate Uncertainty'}</span>
            </button>
          </div>
        </form>

        {/* Prediction & Uncertainty Diagnostics Panel */}
        <div className="lg:col-span-7 space-y-6">
          {!result ? (
            <div className="bg-white border border-slate-200 rounded-xl p-10 text-center">
              <HelpCircle className="w-8 h-8 text-blue-600 mx-auto" />
              <h3 className="mt-3 text-base font-semibold text-slate-900">
                Submit an Application to View Uncertainty Diagnostics
              </h3>
              <p className="mt-1.5 text-sm text-slate-500 max-w-md mx-auto">
                The engine evaluates 6 machine learning models and 14 bootstrap resamples to separate Default
                Probability from Epistemic Uncertainty and identify borderline decisions.
              </p>
            </div>
          ) : (
            <>
              {/* Decision & Risk Banner */}
              <div className="bg-white border border-slate-200 rounded-xl p-6">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <div className="text-xs text-slate-500 font-mono">
                      {savedRecord?.application_ref || 'LIVE-INFERENCE'} · DTI {(result.dti_ratio * 100).toFixed(1)}% · LTI {result.lti_ratio.toFixed(2)}x
                    </div>
                    <div className="mt-1 flex items-center gap-2.5">
                      {result.prediction === 'Likely to Repay' ? (
                        <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                      ) : (
                        <AlertTriangle className="w-6 h-6 text-rose-600 shrink-0" />
                      )}
                      <h3 className="text-2xl font-bold text-slate-900">{result.prediction}</h3>
                    </div>
                    <p className="mt-1.5 text-sm text-slate-600">{result.recommended_action}</p>
                  </div>

                  <div className="text-right">
                    <div className="text-xs text-slate-500">Risk Classification</div>
                    <div
                      className={`mt-1 text-lg font-bold ${
                        result.risk_category === 'High Risk'
                          ? 'text-rose-700'
                          : result.risk_category === 'Medium Risk'
                          ? 'text-amber-700'
                          : 'text-emerald-700'
                      }`}
                    >
                      {result.risk_category}
                    </div>
                    {savedRecord && (
                      <a
                        href={`/api/reports/${savedRecord.id}?format=html`}
                        className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md transition-colors whitespace-nowrap"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download Report</span>
                      </a>
                    )}
                  </div>
                </div>

                {/* Crucial Distinction: Default Probability VS Uncertainty / Confidence */}
                <div className="mt-6 pt-6 border-t border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-700">1. Default Probability P(Default)</span>
                      <span className="text-xl font-bold font-mono tabular-nums text-slate-900">
                        {(result.default_probability * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="mt-2 h-2.5 w-full bg-slate-200 rounded-sm overflow-hidden">
                      <div
                        className={`h-full ${
                          result.default_probability >= 0.6
                            ? 'bg-rose-600'
                            : result.default_probability >= 0.3
                            ? 'bg-amber-500'
                            : 'bg-emerald-600'
                        }`}
                        style={{ width: `${result.default_probability * 100}%` }}
                      />
                    </div>
                    <div className="mt-2 text-xs text-slate-600">
                      90% Bootstrap Interval:{' '}
                      <span className="font-mono font-medium text-slate-900">
                        [{(result.ci_low * 100).toFixed(1)}% – {(result.ci_high * 100).toFixed(1)}%]
                      </span>
                    </div>
                    <p className="mt-1.5 text-xs text-slate-500">
                      Measures estimated likelihood of borrower default, not how sure the models are.
                    </p>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-700">2. Prediction Confidence (1 - Uncertainty)</span>
                      <span className="text-xl font-bold font-mono tabular-nums text-blue-700">
                        {(result.confidence_score * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="mt-2 h-2.5 w-full bg-slate-200 rounded-sm overflow-hidden">
                      <div
                        className="h-full bg-blue-600"
                        style={{ width: `${result.confidence_score * 100}%` }}
                      />
                    </div>
                    <div className="mt-2 flex items-center justify-between text-xs text-slate-600">
                      <span>
                        Uncertainty Score:{' '}
                        <strong className="font-mono text-slate-900">
                          {(result.uncertainty_score * 100).toFixed(1)}%
                        </strong>
                      </span>
                      <span className={result.is_uncertain ? 'font-semibold text-amber-700' : 'text-emerald-700 font-medium'}>
                        {result.uncertainty_level}
                      </span>
                    </div>
                    <p className="mt-1.5 text-xs text-slate-500">
                      Combines bootstrap variance ({(result.bootstrap_std * 100).toFixed(1)}%), model spread (
                      {(result.model_disagreement * 100).toFixed(1)}%), and entropy.
                    </p>
                  </div>
                </div>

                {/* Why This Prediction May Be Uncertain */}
                <div className="mt-5 rounded-lg border border-slate-200 p-4 bg-white">
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <h4 className="text-sm font-semibold text-slate-900">
                      Uncertainty Explanation & Diagnostic Signals
                    </h4>
                    <span
                      className={`text-xs font-semibold ${
                        result.is_uncertain ? 'text-amber-700' : 'text-emerald-700'
                      }`}
                    >
                      {result.is_uncertain ? 'Flagged: Uncertain Prediction' : 'Consensus Verified'}
                    </span>
                  </div>
                  <ul className="space-y-1.5 text-xs text-slate-700 list-disc pl-4">
                    {result.uncertainty_reasons.map((reason, idx) => (
                      <li key={idx}>{reason}</li>
                    ))}
                  </ul>
                  {result.preprocessing_notes.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-slate-100">
                      <div className="text-xs font-medium text-slate-700 mb-1">Preprocessing Audit Log:</div>
                      <ul className="space-y-1 text-xs text-slate-600 list-disc pl-4">
                        {result.preprocessing_notes.map((n, i) => (
                          <li key={i}>{n}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>

              {/* Per-Model Agreement Breakdown */}
              <div className="bg-white border border-slate-200 rounded-xl p-6">
                <h4 className="text-sm font-semibold text-slate-900 mb-3">
                  Model-by-Model Default Probability Breakdown
                </h4>
                <div className="space-y-2.5">
                  {modelRows.map((m) => (
                    <div key={m.name} className="grid grid-cols-12 items-center gap-3 text-xs">
                      <div className={`col-span-5 ${m.primary ? 'font-semibold text-blue-800' : 'text-slate-700'}`}>
                        {m.name}
                      </div>
                      <div className="col-span-5 h-2 bg-slate-100 rounded-sm overflow-hidden">
                        <div
                          className={`h-full ${m.primary ? 'bg-blue-700' : 'bg-slate-500'}`}
                          style={{ width: `${m.prob * 100}%` }}
                        />
                      </div>
                      <div className="col-span-2 text-right font-mono tabular-nums font-medium text-slate-900">
                        {(m.prob * 100).toFixed(1)}%
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
