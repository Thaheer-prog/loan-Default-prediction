import React from 'react';
import { DatasetSummary, ModelMetric } from '../types';

export function DocsView({
  models,
  datasetSummary,
}: {
  models: ModelMetric[];
  datasetSummary: DatasetSummary | null;
}) {
  const bestModel = [...models].sort((a, b) => b.roc_auc - a.roc_auc)[0];
  const ensemble = models.find((m) => m.key === 'soft_voting_ensemble');

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="bg-white border border-slate-200 rounded-xl p-8 space-y-6">
        <div className="border-b border-slate-200 pb-5">
          <div className="text-xs font-medium text-blue-700">B.Tech Project Engineering Report</div>
          <h2 className="mt-1 text-2xl font-bold text-slate-900">
            Uncertainty-Aware Ensemble Learning for Loan Default Prediction
          </h2>
          <p className="mt-2 text-sm text-slate-600">
            Complete project documentation, architecture specification, mathematical uncertainty formulation, and
            reproducible Python/Flask repository guide.
          </p>
        </div>

        <section className="space-y-2">
          <h3 className="text-base font-semibold text-slate-900">01. Introduction & Problem Statement</h3>
          <p className="text-sm text-slate-600 leading-relaxed">
            Financial institutions evaluate thousands of retail credit applications daily. Standard binary classifiers
            predict either repayment (0) or default (1) alongside a point probability, which masks epistemic uncertainty
            in sparse, conflicting, or borderline borrower profiles. This project addresses overconfident automated
            decisions by quantifying predictive uncertainty alongside default likelihood.
          </p>
        </section>

        <section className="space-y-2">
          <h3 className="text-base font-semibold text-slate-900">02. Objectives</h3>
          <ul className="list-disc pl-5 text-sm text-slate-600 space-y-1">
            <li>Preprocess heterogeneous applicant records with median/mode imputation, IQR outlier winsorization, and scaling.</li>
            <li>Train and benchmark Logistic Regression, Decision Tree, Random Forest, Gradient Boosting, XGBoost, and a Soft Voting Ensemble.</li>
            <li>Quantify epistemic and aleatoric uncertainty via Bootstrap resampling, inter-model standard deviation, and Shannon entropy.</li>
            <li>Separate Default Probability from Prediction Confidence and provide automated explanations for uncertain flags.</li>
            <li>Persist all assessments in SQLite with downloadable individual and portfolio reports.</li>
          </ul>
        </section>

        <section className="space-y-2">
          <h3 className="text-base font-semibold text-slate-900">03. Literature Review & Existing vs. Proposed System</h3>
          <p className="text-sm text-slate-600 leading-relaxed">
            Classical credit scorecards rely on Logistic Regression for interpretability, whereas modern credit risk
            pipelines use Random Forests and XGBoost (Chen & Guestrin, 2016) for higher discriminatory power. Deep
            ensembles and bootstrap ensembles (Lakshminarayanan et al., 2017) demonstrate that model disagreement and
            predictive entropy effectively detect out-of-distribution and ambiguous inputs. Unlike existing black-box
            systems that output only a single score, our proposed system combines multi-family Soft Voting with
            bootstrap confidence intervals and human-readable uncertainty explanations.
          </p>
        </section>

        <section className="space-y-2">
          <h3 className="text-base font-semibold text-slate-900">04. Methodology & Uncertainty Formulation</h3>
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 text-xs text-slate-700 space-y-2 font-mono">
            <div>1. P_ensemble(y=1|x) = 0.14*P_LR + 0.04*P_DT + 0.22*P_RF + 0.28*P_GB + 0.32*P_XGB</div>
            <div>2. Bootstrap Uncertainty (sigma_boot) = std(P_b(y=1|x) for b = 1..B bootstrap models)</div>
            <div>3. Model Disagreement (sigma_models) = std(P_LR, P_DT, P_RF, P_GB, P_XGB)</div>
            <div>4. Predictive Entropy H(p) = -(p*log2(p) + (1-p)*log2(1-p))</div>
            <div>5. Composite Uncertainty U = clip(0.42*norm(sigma_boot) + 0.33*norm(sigma_models) + 0.25*H(p) + OOD_penalty)</div>
            <div>6. Prediction Confidence = 1 - U (Explicitly decoupled from P_ensemble)</div>
          </div>
        </section>

        <section className="space-y-2">
          <h3 className="text-base font-semibold text-slate-900">05. Empirical Results & Discussion</h3>
          <p className="text-sm text-slate-600 leading-relaxed">
            Evaluated on the {datasetSummary?.test_records ?? 241}-record stratified test split of the{' '}
            {datasetSummary?.total_records ?? 1200}-record synthetic demonstration dataset,{' '}
            {bestModel ? `${bestModel.model} achieved the highest ROC-AUC (${(bestModel.roc_auc * 100).toFixed(2)}%)` : 'the tree ensembles outperformed single baselines'},{' '}
            while the Soft Voting Ensemble achieved{' '}
            {ensemble ? `${(ensemble.accuracy * 100).toFixed(2)}% Accuracy, ${(ensemble.precision * 100).toFixed(2)}% Precision, and ${(ensemble.roc_auc * 100).toFixed(2)}% ROC-AUC` : 'balanced performance'}{' '}
            with smoother probability calibration and reliable uncertainty separation.
          </p>
        </section>

        <section className="space-y-2">
          <h3 className="text-base font-semibold text-slate-900">06. Python/Flask GitHub-Ready Project Structure</h3>
          <pre className="bg-slate-900 text-slate-100 rounded-lg p-4 text-xs font-mono overflow-x-auto leading-relaxed">
{`Loan-Default-Prediction/
├── app.py                   # Flask server, validation, SQLite & inference endpoints
├── train_model.py           # Scikit-learn + XGBoost training, Bootstrap & Matplotlib plots
├── requirements.txt         # Python dependencies (Flask, scikit-learn, xgboost, seaborn...)
├── README.md                # Installation, commands & architectural guide
├── dataset/
│   ├── generate_dataset.py  # Reproducible 1,200-record credit demonstration generator
│   └── loan_data.csv        # Synthetic dataset with controlled missing values & outliers
├── models/                  # Trained joblib pipelines & scaler artifacts
├── evaluation/              # ROC curves, confusion matrices & metrics JSON
├── database/
│   ├── schema.sql           # SQLite table & index DDL
│   ├── db.py                # SQLite CRUD helper module
│   └── loan_default.db      # Persistent SQLite database
├── templates/               # Bootstrap 5 Jinja2 templates (index, dashboard, predict, models, history, docs)
├── static/                  # Custom CSS & interactive frontend JS
├── docs/
│   └── PROJECT_DOCUMENTATION.md  # Full 16-section academic B.Tech report
└── tests/
    └── test_app.py          # Automated unit & integration tests`}
          </pre>
        </section>

        <section className="space-y-2">
          <h3 className="text-base font-semibold text-slate-900">07. Limitations & Educational Notice</h3>
          <p className="text-sm text-slate-600 leading-relaxed">
            This application is an individual B.Tech educational prototype trained on a synthetic demonstration dataset.
            It must not be used for real-world lending, underwriting, or regulatory credit decisions without validated
            historical bureau data, fairness auditing, and formal model risk governance.
          </p>
        </section>
      </div>
    </div>
  );
}
