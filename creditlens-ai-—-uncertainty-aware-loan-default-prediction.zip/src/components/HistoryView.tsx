import React, { useMemo, useState } from 'react';
import { Download, Search, Trash2, Eye } from 'lucide-react';
import { StoredPredictionRecord } from '../types';

export function HistoryView({
  records,
  onDelete,
  onSelectRecord,
}: {
  records: StoredPredictionRecord[];
  onDelete: (id: number) => Promise<void>;
  onSelectRecord: (rec: StoredPredictionRecord) => void;
}) {
  const [query, setQuery] = useState('');
  const [riskFilter, setRiskFilter] = useState<string>('all');
  const [uncertainOnly, setUncertainOnly] = useState(false);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return records.filter((r) => {
      if (riskFilter !== 'all' && r.risk_category !== riskFilter) return false;
      if (uncertainOnly && !r.is_uncertain) return false;
      if (
        q &&
        !r.applicant_name.toLowerCase().includes(q) &&
        !r.application_ref.toLowerCase().includes(q) &&
        !r.employment_status.toLowerCase().includes(q)
      ) {
        return false;
      }
      return true;
    });
  }, [records, query, riskFilter, uncertainOnly]);

  return (
    <div className="space-y-6">
      {/* Filter & Export Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[260px]">
          <div className="relative flex-1 max-w-xs">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search applicant or ref ID..."
              className="w-full pl-9 pr-3 py-1.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            {['all', 'Low Risk', 'Medium Risk', 'High Risk'].map((tier) => (
              <button
                key={tier}
                type="button"
                onClick={() => setRiskFilter(tier)}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  riskFilter === tier ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tier === 'all' ? 'All Tiers' : tier}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => setUncertainOnly((v) => !v)}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              uncertainOnly
                ? 'bg-amber-50 border-amber-300 text-amber-900'
                : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
            }`}
          >
            Uncertain Only
          </button>
        </div>

        <a
          href="/api/reports/export-csv"
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Download Full CSV Report</span>
        </a>
      </div>

      {/* SQLite History Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold text-slate-900">SQLite Prediction History</h2>
            <p className="text-xs text-slate-500">
              Showing {filtered.length} of {records.length} stored loan assessments
            </p>
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="p-12 text-center text-sm text-slate-500">
            No matching prediction records found in SQLite storage.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-600">
                  <th className="py-3 px-4">Applicant</th>
                  <th className="py-3 px-4 text-right">Income / Loan</th>
                  <th className="py-3 px-4 text-right">Default Prob</th>
                  <th className="py-3 px-4 text-right">Confidence</th>
                  <th className="py-3 px-4 text-right">Uncertainty (90% CI)</th>
                  <th className="py-3 px-4">Risk Tier</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900">{r.applicant_name}</div>
                      <div className="text-xs text-slate-500 font-mono">
                        {r.application_ref} · {new Date(r.created_at).toLocaleDateString()}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-xs text-slate-700">
                      <div>${r.applicant_income.toLocaleString()}/yr</div>
                      <div className="text-slate-500">${r.loan_amount.toLocaleString()} ({r.loan_term}m)</div>
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-slate-900">
                      {(r.default_probability * 100).toFixed(1)}%
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                      {(r.confidence_score * 100).toFixed(1)}%
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-xs">
                      <div className={r.is_uncertain ? 'text-amber-700 font-semibold' : 'text-slate-700'}>
                        {(r.uncertainty_score * 100).toFixed(1)}% {r.is_uncertain ? '(Uncertain)' : ''}
                      </div>
                      <div className="text-slate-500">
                        [{(r.ci_low * 100).toFixed(0)}–{(r.ci_high * 100).toFixed(0)}%]
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div
                        className={`text-xs font-semibold ${
                          r.risk_category === 'High Risk'
                            ? 'text-rose-700'
                            : r.risk_category === 'Medium Risk'
                            ? 'text-amber-700'
                            : 'text-emerald-700'
                        }`}
                      >
                        {r.risk_category}
                      </div>
                      <div className="text-xs text-slate-500">{r.prediction}</div>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => onSelectRecord(r)}
                          title="Inspect Prediction Details"
                          className="p-1.5 text-slate-600 hover:text-blue-700 hover:bg-blue-50 rounded-md cursor-pointer"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <a
                          href={`/api/reports/${r.id}?format=html`}
                          title="Download HTML Report"
                          className="p-1.5 text-slate-600 hover:text-blue-700 hover:bg-blue-50 rounded-md"
                        >
                          <Download className="w-4 h-4" />
                        </a>
                        <button
                          type="button"
                          onClick={() => onDelete(r.id)}
                          title="Delete Record"
                          className="p-1.5 text-slate-500 hover:text-rose-700 hover:bg-rose-50 rounded-md cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
