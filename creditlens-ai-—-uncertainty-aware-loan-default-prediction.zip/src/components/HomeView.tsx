import React from 'react';
import { ArrowRight, BarChart3, ShieldAlert, FileCheck2, Layers } from 'lucide-react';
import { DashboardPayload } from '../types';

export type NavTab = 'home' | 'dashboard' | 'predict' | 'models' | 'history' | 'docs';

export function HomeView({
  dashboard,
  onNavigate,
}: {
  dashboard: DashboardPayload | null;
  onNavigate: (tab: NavTab) => void;
}) {
  const totalDataset = dashboard?.dataset_summary.total_records ?? 1200;
  const ensembleAuc = dashboard ? (dashboard.ensemble_auc * 100).toFixed(1) : '78.3';

  return (
    <div className="space-y-8">
      {/* Hero Banner */}
      <section className="bg-white border border-slate-200 rounded-xl p-8 lg:p-10">
        <div className="max-w-3xl">
          <div className="text-xs font-medium text-blue-700 tracking-wide">
            B.Tech Artificial Intelligence & Machine Learning Project · Educational Prototype
          </div>
          <h1 className="mt-3 text-3xl lg:text-4xl font-bold tracking-tight text-slate-900 text-balance">
            Uncertainty-Aware Ensemble Learning for Loan Default Prediction
          </h1>
          <p className="mt-4 text-base text-slate-600 leading-relaxed max-w-2xl">
            Conventional credit scoring models emit a single point probability without telling underwriters how much
            the model actually knows. CreditLens AI pairs a 5-algorithm Soft Voting Ensemble with bootstrap resampling
            and inter-model disagreement to quantify epistemic uncertainty alongside default probability.
          </p>
          <div className="mt-7 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => onNavigate('predict')}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>Run Loan Risk Assessment</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => onNavigate('dashboard')}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>View Portfolio Dashboard</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('models')}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-blue-700 hover:text-blue-900 text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>Compare 6 ML Algorithms</span>
            </button>
          </div>
        </div>

        {/* Quantitative Summary Strip */}
        <div className="mt-9 pt-7 border-t border-slate-200 grid grid-cols-2 lg:grid-cols-4 gap-6">
          <div>
            <div className="text-xs text-slate-500">Training & Evaluation Corpus</div>
            <div className="mt-1 text-2xl font-bold font-mono tabular-nums text-slate-900">
              {totalDataset.toLocaleString()} records
            </div>
            <div className="mt-0.5 text-xs text-slate-500">80/20 stratified split</div>
          </div>
          <div>
            <div className="text-xs text-slate-500">Ensemble Algorithms</div>
            <div className="mt-1 text-2xl font-bold font-mono tabular-nums text-slate-900">6 models</div>
            <div className="mt-0.5 text-xs text-slate-500">LR, DT, RF, GB, XGB, Soft Vote</div>
          </div>
          <div>
            <div className="text-xs text-slate-500">Ensemble ROC-AUC</div>
            <div className="mt-1 text-2xl font-bold font-mono tabular-nums text-blue-700">{ensembleAuc}%</div>
            <div className="mt-0.5 text-xs text-slate-500">Evaluated on held-out test set</div>
          </div>
          <div>
            <div className="text-xs text-slate-500">Uncertainty Estimators</div>
            <div className="mt-1 text-2xl font-bold font-mono tabular-nums text-slate-900">14 + 5</div>
            <div className="mt-0.5 text-xs text-slate-500">Bootstrap models + model spread</div>
          </div>
        </div>
      </section>

      {/* Core Value Pillars */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <h2 className="mt-4 text-lg font-semibold text-slate-900">
            Probability Is Not Certainty
          </h2>
          <p className="mt-2 text-sm text-slate-600 leading-relaxed">
            A 51% default probability could come from unanimous model agreement on a borderline borrower or from
            violent disagreement between linear and tree-based models. We report Default Probability, Bootstrap 90%
            Confidence Interval, and Prediction Confidence separately so underwriters never confuse risk score with model certainty.
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center">
            <Layers className="w-5 h-5" />
          </div>
          <h2 className="mt-4 text-lg font-semibold text-slate-900">
            Automated Preprocessing & Outlier Guardrails
          </h2>
          <p className="mt-2 text-sm text-slate-600 leading-relaxed">
            Incoming applications pass through median/mode imputation, IQR outlier capping, engineered Debt-to-Income
            (DTI) and Loan-to-Income (LTI) ratios, one-hot encoding, and standard scaling. Any out-of-distribution
            adjustments are surfaced directly in the uncertainty explanation.
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center">
            <BarChart3 className="w-5 h-5" />
          </div>
          <h2 className="mt-4 text-lg font-semibold text-slate-900">
            Real Test-Set Benchmarking
          </h2>
          <p className="mt-2 text-sm text-slate-600 leading-relaxed">
            Compare Logistic Regression, Decision Tree, Random Forest, Gradient Boosting, XGBoost, and the Soft Voting
            Ensemble side-by-side on Accuracy, Precision, Recall, F1-Score, ROC-AUC, and Confusion Matrices computed
            live from the dataset.
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-6">
          <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center">
            <FileCheck2 className="w-5 h-5" />
          </div>
          <h2 className="mt-4 text-lg font-semibold text-slate-900">
            SQLite Audit Trail & Report Export
          </h2>
          <p className="mt-2 text-sm text-slate-600 leading-relaxed">
            Every loan assessment—alongside its default probability, uncertainty score, confidence interval, and
            human-readable uncertainty rationale—is persisted to SQLite and exportable as individual HTML assessment
            reports or full portfolio CSV logs.
          </p>
        </div>
      </section>
    </div>
  );
}
