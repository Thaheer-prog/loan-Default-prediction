import React, { useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { DatasetSummary, FeatureImportanceItem, ModelMetric } from '../types';
import { ConfusionMatrixCard, FeatureImportanceChart, RocCurveChart } from './Charts';

export function ModelsView({
  models,
  featureImportance,
  datasetSummary,
  onRetrain,
}: {
  models: ModelMetric[];
  featureImportance: FeatureImportanceItem[];
  datasetSummary: DatasetSummary | null;
  onRetrain: () => Promise<void>;
}) {
  const [selectedKey, setSelectedKey] = useState<string>('soft_voting_ensemble');
  const [retraining, setRetraining] = useState(false);

  const activeModel = models.find((m) => m.key === selectedKey) || models[models.length - 1];

  const handleRetrain = async () => {
    setRetraining(true);
    try {
      await onRetrain();
    } finally {
      setRetraining(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Summary */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-slate-900">
            Algorithm Comparison & Held-Out Test Evaluation
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            {datasetSummary
              ? `Evaluated on ${datasetSummary.test_records} stratified test records (${datasetSummary.train_records} training records · ${datasetSummary.missing_values_imputed} missing values imputed · ${datasetSummary.outliers_capped} outliers capped).`
              : 'Loading dataset evaluation summary...'}
          </p>
        </div>
        <button
          type="button"
          onClick={handleRetrain}
          disabled={retraining}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${retraining ? 'animate-spin' : ''}`} />
          <span>{retraining ? 'Retraining Models...' : 'Retrain Ensemble on Dataset'}</span>
        </button>
      </div>

      {/* Benchmark Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200">
          <h3 className="text-base font-semibold text-slate-900">Classification Performance Metrics</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-600">
                <th className="py-3 px-4">Algorithm</th>
                <th className="py-3 px-4 text-right">Accuracy</th>
                <th className="py-3 px-4 text-right">Precision</th>
                <th className="py-3 px-4 text-right">Recall</th>
                <th className="py-3 px-4 text-right">F1-Score</th>
                <th className="py-3 px-4 text-right">ROC-AUC</th>
                <th className="py-3 px-4 text-right">Confusion Matrix</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {models.map((m) => {
                const isSelected = m.key === selectedKey;
                const isEnsemble = m.key === 'soft_voting_ensemble';
                return (
                  <tr
                    key={m.key}
                    onClick={() => setSelectedKey(m.key)}
                    className={`cursor-pointer transition-colors ${
                      isSelected ? 'bg-blue-50/70' : 'hover:bg-slate-50'
                    }`}
                  >
                    <td className="py-3 px-4 font-medium text-slate-900">
                      {m.model}
                      {isEnsemble ? ' (Primary)' : ''}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      {(m.accuracy * 100).toFixed(2)}%
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      {(m.precision * 100).toFixed(2)}%
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      {(m.recall * 100).toFixed(2)}%
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      {(m.f1_score * 100).toFixed(2)}%
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-blue-700">
                      {(m.roc_auc * 100).toFixed(2)}%
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedKey(m.key);
                        }}
                        className="text-xs font-medium text-blue-700 hover:underline cursor-pointer whitespace-nowrap"
                      >
                        Inspect Matrix
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* ROC Curve + Confusion Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6">
          <h3 className="text-base font-semibold text-slate-900 mb-1">ROC Curve Comparison</h3>
          <p className="text-xs text-slate-500 mb-4">
            Click a model legend button below the plot to isolate its Receiver Operating Characteristic curve.
          </p>
          <RocCurveChart models={models} />
        </div>

        <div className="lg:col-span-5 space-y-6">
          {activeModel && (
            <div className="bg-white border border-slate-200 rounded-xl p-6">
              <div className="flex items-center justify-between gap-2 mb-4">
                <div>
                  <h3 className="text-base font-semibold text-slate-900">Confusion Matrix</h3>
                  <p className="text-xs text-slate-500">{activeModel.model}</p>
                </div>
                <select
                  value={selectedKey}
                  onChange={(e) => setSelectedKey(e.target.value)}
                  className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-md bg-white"
                  aria-label="Select model confusion matrix"
                >
                  {models.map((m) => (
                    <option key={m.key} value={m.key}>
                      {m.model}
                    </option>
                  ))}
                </select>
              </div>
              <ConfusionMatrixCard model={activeModel} />
            </div>
          )}

          <div className="bg-white border border-slate-200 rounded-xl p-6">
            <h3 className="text-base font-semibold text-slate-900 mb-1">Ensemble Feature Importance</h3>
            <p className="text-xs text-slate-500 mb-4">
              Relative drop in ROC-AUC under test-set feature permutation.
            </p>
            <FeatureImportanceChart items={featureImportance} />
          </div>
        </div>
      </div>
    </div>
  );
}
