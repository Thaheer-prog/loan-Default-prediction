import React, { useCallback, useEffect, useState } from 'react';
import {
  Activity,
  BarChart3,
  BookOpen,
  Database,
  Download,
  FilePlus2,
  Home,
  Menu,
  X,
} from 'lucide-react';
import { DashboardPayload, DatasetSummary, FeatureImportanceItem, ModelMetric, StoredPredictionRecord } from './types';
import { HomeView, NavTab } from './components/HomeView';
import { DashboardView } from './components/DashboardView';
import { PredictView } from './components/PredictView';
import { ModelsView } from './components/ModelsView';
import { HistoryView } from './components/HistoryView';
import { DocsView } from './components/DocsView';

const NAV_ITEMS: { id: NavTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'home', label: 'Overview', icon: Home },
  { id: 'dashboard', label: 'Portfolio Dashboard', icon: Activity },
  { id: 'predict', label: 'Loan Assessment', icon: FilePlus2 },
  { id: 'models', label: 'Model Comparison', icon: BarChart3 },
  { id: 'history', label: 'Prediction History', icon: Database },
  { id: 'docs', label: 'Project Docs', icon: BookOpen },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [dashboard, setDashboard] = useState<DashboardPayload | null>(null);
  const [models, setModels] = useState<ModelMetric[]>([]);
  const [featureImportance, setFeatureImportance] = useState<FeatureImportanceItem[]>([]);
  const [datasetSummary, setDatasetSummary] = useState<DatasetSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedRecord, setSelectedRecord] = useState<StoredPredictionRecord | null>(null);

  const fetchAll = useCallback(async () => {
    try {
      const [dashResp, modResp] = await Promise.all([fetch('/api/dashboard'), fetch('/api/models')]);
      if (dashResp.ok) {
        const dashJson: DashboardPayload = await dashResp.json();
        setDashboard(dashJson);
      }
      if (modResp.ok) {
        const modJson = await modResp.json();
        setModels(modJson.models || []);
        setFeatureImportance(modJson.feature_importance || []);
        setDatasetSummary(modJson.dataset_summary || null);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  const handleRetrain = async () => {
    const resp = await fetch('/api/models/retrain', { method: 'POST' });
    if (resp.ok) {
      await fetchAll();
    }
  };

  const handleDeleteRecord = async (id: number) => {
    const resp = await fetch(`/api/history/${id}`, { method: 'DELETE' });
    if (resp.ok) {
      if (selectedRecord?.id === id) setSelectedRecord(null);
      await fetchAll();
    }
  };

  const handleNavigate = (tab: NavTab) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
  };

  const activeNavLabel = NAV_ITEMS.find((n) => n.id === activeTab)?.label || 'Overview';

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex">
      {/* Mobile Sidebar Backdrop */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 bg-slate-900/40 z-30 lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Left Navigation Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 bg-white border-r border-slate-200 flex flex-col transition-transform duration-200 lg:static lg:translate-x-0 ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="h-16 px-5 border-b border-slate-200 flex items-center justify-between">
          <button
            type="button"
            onClick={() => handleNavigate('home')}
            className="text-left font-display text-base font-bold tracking-tight text-slate-900 whitespace-nowrap cursor-pointer"
          >
            CreditLens <span className="text-blue-700">AI</span>
          </button>
          <button
            type="button"
            onClick={() => setMobileMenuOpen(false)}
            className="p-1.5 text-slate-500 hover:text-slate-800 lg:hidden"
            aria-label="Close navigation"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNavigate(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                  active
                    ? 'bg-blue-50 text-blue-800 font-semibold'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-blue-700' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-200 text-xs text-slate-500 space-y-1">
          <div className="font-medium text-slate-700">Educational Prototype</div>
          <p className="leading-relaxed">
            Demonstrates uncertainty-aware ensemble learning on synthetic data. Not for production lending.
          </p>
        </div>
      </aside>

      {/* Main Content Shell */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar Contract: Breadcrumb on left, 1 primary action on right */}
        <header className="h-16 bg-white border-b border-slate-200 px-4 lg:px-8 flex items-center justify-between gap-4 sticky top-0 z-20">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="p-2 -ml-2 text-slate-600 hover:text-slate-900 lg:hidden"
              aria-label="Open navigation"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="text-sm text-slate-500 truncate">
              <span>Loan Risk Analytics</span>
              <span className="mx-2 text-slate-300">/</span>
              <span className="font-semibold text-slate-900">{activeNavLabel}</span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => handleNavigate('predict')}
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            New Assessment
          </button>
        </header>

        {/* Main Workspace Viewport */}
        <main className="flex-1 p-4 lg:p-8 max-w-7xl w-full mx-auto">
          {activeTab === 'home' && <HomeView dashboard={dashboard} onNavigate={handleNavigate} />}
          {activeTab === 'dashboard' && (
            <DashboardView
              dashboard={dashboard}
              featureImportance={featureImportance}
              loading={loading}
              onNavigate={handleNavigate}
              onSelectRecord={setSelectedRecord}
            />
          )}
          {activeTab === 'predict' && <PredictView onSaved={fetchAll} />}
          {activeTab === 'models' && (
            <ModelsView
              models={models}
              featureImportance={featureImportance}
              datasetSummary={datasetSummary}
              onRetrain={handleRetrain}
            />
          )}
          {activeTab === 'history' && (
            <HistoryView
              records={dashboard?.all_records || []}
              onDelete={handleDeleteRecord}
              onSelectRecord={setSelectedRecord}
            />
          )}
          {activeTab === 'docs' && <DocsView models={models} datasetSummary={datasetSummary} />}
        </main>

        <footer className="border-t border-slate-200 bg-white px-4 lg:px-8 py-4 text-xs text-slate-500 flex flex-wrap items-center justify-between gap-2">
          <span>Uncertainty-Aware Ensemble Learning for Loan Default Prediction · Individual B.Tech Project</span>
          <span>Educational Prototype · Synthetic Demonstration Dataset</span>
        </footer>
      </div>

      {/* Record Inspection Modal */}
      {selectedRecord && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4"
          onClick={() => setSelectedRecord(null)}
        >
          <div
            className="bg-white border border-slate-200 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 pb-4">
              <div>
                <div className="text-xs font-mono text-slate-500">
                  {selectedRecord.application_ref} · {new Date(selectedRecord.created_at).toLocaleString()}
                </div>
                <h3 className="mt-1 text-xl font-bold text-slate-900">{selectedRecord.applicant_name}</h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedRecord(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-md cursor-pointer"
                aria-label="Close details"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                <div className="text-xs text-slate-500">Prediction</div>
                <div className="mt-1 text-sm font-bold text-slate-900">{selectedRecord.prediction}</div>
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                <div className="text-xs text-slate-500">Default Prob</div>
                <div className="mt-1 text-sm font-bold font-mono tabular-nums text-slate-900">
                  {(selectedRecord.default_probability * 100).toFixed(1)}%
                </div>
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                <div className="text-xs text-slate-500">Confidence</div>
                <div className="mt-1 text-sm font-bold font-mono tabular-nums text-blue-700">
                  {(selectedRecord.confidence_score * 100).toFixed(1)}%
                </div>
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                <div className="text-xs text-slate-500">Uncertainty</div>
                <div className="mt-1 text-sm font-bold font-mono tabular-nums text-amber-700">
                  {(selectedRecord.uncertainty_score * 100).toFixed(1)}%
                </div>
              </div>
            </div>

            <div className="text-xs text-slate-700 grid grid-cols-2 gap-y-2 gap-x-4 border-t border-slate-200 pt-4">
              <div>Annual Income: <span className="font-mono font-medium">${selectedRecord.applicant_income.toLocaleString()}</span></div>
              <div>Loan Amount: <span className="font-mono font-medium">${selectedRecord.loan_amount.toLocaleString()} ({selectedRecord.loan_term}m)</span></div>
              <div>Credit History: <span className="font-medium">{selectedRecord.credit_history === 1 ? 'Clean (1)' : 'Delinquent (0)'}</span></div>
              <div>DTI Ratio: <span className="font-mono font-medium">{(selectedRecord.dti_ratio * 100).toFixed(1)}%</span></div>
              <div>Employment: <span className="font-medium">{selectedRecord.employment_status}</span></div>
              <div>90% Bootstrap CI: <span className="font-mono font-medium">[{(selectedRecord.ci_low * 100).toFixed(1)}% – {(selectedRecord.ci_high * 100).toFixed(1)}%]</span></div>
            </div>

            <div className="border-t border-slate-200 pt-4">
              <div className="text-xs font-semibold text-slate-900 mb-2">
                Uncertainty Diagnostic Rationale ({selectedRecord.is_uncertain ? 'Uncertain Case' : 'High Consensus'})
              </div>
              <ul className="list-disc pl-4 space-y-1 text-xs text-slate-600">
                {selectedRecord.uncertainty_reasons.map((r, i) => (
                  <li key={i}>{r}</li>
                ))}
              </ul>
            </div>

            <div className="border-t border-slate-200 pt-4 flex items-center justify-end gap-3">
              <a
                href={`/api/reports/${selectedRecord.id}?format=html`}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download HTML Report</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
